import { readdir, stat } from "node:fs/promises";
import { basename, dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import type {
  Benchmark,
  BenchmarkDefinition,
  Eval,
  EvalDefinition,
  ModelRef,
} from "../types";
import { CANDIDATE_TIMEOUT_MS } from "../types";
import { rubricCriteria } from "../judgment";
import { compileCodeJudge } from "../infra/judging/code-source";
import { OPENCODE_VERSION, RUNTIME_IMAGE } from "../infra/opencode/version";
import { monitorPolicy } from "./monitor-policy";
import {
  fingerprint,
  hash,
  relativePath,
  treeHash,
  contained,
} from "../infra/files";

const positive = (value: unknown, fallback: number, label: string) => {
  const result = value ?? fallback;
  if (typeof result !== "number" || !Number.isInteger(result) || result < 1)
    throw new Error(`${label} must be a positive integer`);
  return result;
};
export const modelRef = (value: unknown): ModelRef => {
  if (
    typeof value !== "string" ||
    !/^[\w.-]+\/[^\s/#]+(?:\/[^\s/#]+)*(?:#[\w.-]+)?$/.test(value)
  )
    throw new Error(`Invalid model reference: ${String(value)}`);
  return value as ModelRef;
};
async function declaration<T>(path: string): Promise<T> {
  const url = pathToFileURL(path);
  url.searchParams.set("version", hash(await Bun.file(path).bytes()));
  return (await import(url.href)).default;
}
async function loadEval(directory: string): Promise<EvalDefinition> {
  const id = basename(directory),
    prompt = Bun.file(resolve(directory, "prompt.md")),
    judge = Bun.file(resolve(directory, "judge.md")),
    codeFile = resolve(directory, "judge.ts");
  const hasMarkdown = await judge.exists(),
    hasCode = await Bun.file(codeFile).exists();
  if (!(await prompt.exists()) || (!hasMarkdown && !hasCode))
    throw new Error(
      `${id} requires prompt.md and at least one of judge.md or judge.ts`,
    );
  const settings = (await Bun.file(resolve(directory, "eval.ts")).exists())
    ? await declaration<Eval>(resolve(directory, "eval.ts"))
    : {};
  if (!settings || typeof settings !== "object")
    throw new Error(`${id}/eval.ts must export a declaration`);
  if (
    Object.keys(settings).some(
      (key) => !["workspace", "prepare", "earlyStop"].includes(key),
    )
  )
    throw new Error(`${id}/eval.ts has unsupported settings`);
  monitorPolicy(settings.earlyStop);
  if (hasCode && settings.earlyStop)
    throw new Error(
      `${id}: judge.ts grades finalized recordings; earlyStop requires a Markdown-only judge`,
    );
  const source: unknown[] = [];
  if (settings.workspace) {
    const workspace = settings.workspace;
    if (
      Object.keys(workspace).some(
        (key) =>
          ![
            "repository",
            "revisions",
            "ref",
            "commit",
            "checkout",
            "remote",
            "overlay",
          ].includes(key),
      )
    )
      throw new Error(`${id}: workspace contains unsupported settings`);
    if (!/^[\w./-]+$/.test(workspace.ref))
      throw new Error(`${id}: workspace ref is invalid`);
    if (workspace.commit && !/^[a-f0-9]{40}$/.test(workspace.commit))
      throw new Error(`${id}: workspace commit must be a full SHA`);
    if (
      [workspace.repository, workspace.revisions].filter(Boolean).length !== 1
    )
      throw new Error(
        `${id}: choose one workspace source: repository or revisions`,
      );
    if (workspace.repository) {
      const url = new URL(workspace.repository);
      if (
        url.protocol !== "https:" ||
        url.username ||
        url.password ||
        !workspace.commit
      )
        throw new Error(
          `${id}: repository requires a credential-free HTTPS URL and a full commit SHA`,
        );
      source.push({
        repository: workspace.repository,
        commit: workspace.commit,
      });
    }
    if (workspace.revisions) {
      if (
        !workspace.revisions.length ||
        !workspace.revisions.some((revision) => revision.ref === workspace.ref)
      )
        throw new Error(`${id}: revisions must include the initial ref`);
      for (const revision of workspace.revisions) {
        if (
          !/^[\w.-]+$/.test(revision.ref) ||
          revision.ref === "preparation" ||
          !revision.message
        )
          throw new Error(`${id}: invalid revision ref/message`);
        source.push(
          await treeHash(
            contained(
              directory,
              relativePath(revision.directory, "Revision files"),
            ),
          ),
        );
      }
    }
    if (workspace.overlay)
      source.push(
        await treeHash(
          contained(
            directory,
            relativePath(workspace.overlay, "Workspace overlay"),
          ),
        ),
      );
    for (const name of [
      workspace.checkout ?? "checkout",
      workspace.remote ?? "upstream",
    ])
      if (!/^[\w-]+$/.test(name))
        throw new Error(`${id}: checkout and remote must be simple names`);
  } else {
    const workspace = resolve(directory, "workspace");
    if (
      await stat(workspace)
        .then((s) => s.isDirectory())
        .catch(() => false)
    )
      source.push(await treeHash(workspace));
  }
  for (const step of settings.prepare ?? []) {
    relativePath(step.cwd, "Preparation working directory");
    if (
      !Array.isArray(step.argv) ||
      !step.argv.length ||
      step.argv.some((arg) => typeof arg !== "string" || !arg)
    )
      throw new Error(`${id}: preparation requires argv`);
  }
  const promptText = await prompt.text(),
    judgeText = hasMarkdown ? await judge.text() : "";
  if (!promptText.trim() || (hasMarkdown && !judgeText.trim()))
    throw new Error(`${id}: prompt and judge must not be empty`);
  const code = hasCode ? await compileCodeJudge(codeFile) : undefined;
  return {
    id,
    directory,
    prompt: promptText,
    judge: judgeText,
    settings,
    sourceHash: fingerprint({
      settings: { workspace: settings.workspace, prepare: settings.prepare },
      source,
    }),
    judgeHash: fingerprint({ rubric: judgeText, code: code?.hash }),
    criteria: hasMarkdown ? rubricCriteria(judgeText) : [],
    ...(code ? { code } : {}),
    name: /^# (.+)$/m.exec(judgeText)?.[1] ?? id,
  };
}

export async function loadBenchmark(
  path: string,
): Promise<BenchmarkDefinition> {
  const directory = resolve(
    path.endsWith("benchmark.ts") ? resolve(path, "..") : path,
  );
  const declarationFile = resolve(directory, "benchmark.ts");
  const definition = await declaration<Benchmark>(declarationFile);
  if (
    !definition ||
    !Array.isArray(definition.models) ||
    !definition.models.length
  )
    throw new Error("benchmark.ts requires models");
  if (
    Object.keys(definition).some(
      (key) =>
        ![
          "name",
          "models",
          "judge",
          "repetitions",
          "concurrency",
          "candidate",
          "container",
        ].includes(key),
    )
  )
    throw new Error("benchmark.ts contains unsupported settings");
  const models = definition.models.map(modelRef);
  if (
    definition.judge !== undefined &&
    (!definition.judge ||
      typeof definition.judge !== "object" ||
      Array.isArray(definition.judge) ||
      Object.keys(definition.judge).some(
        (key) => !["model", "timeoutMs", "websearch"].includes(key),
      ))
  )
    throw new Error(
      "judge must be an object with model, timeoutMs, or websearch settings",
    );
  if (new Set(models).size !== models.length)
    throw new Error("Benchmark contains duplicate models");
  const timeoutMs = positive(
    definition.candidate?.timeoutMs,
    CANDIDATE_TIMEOUT_MS,
    "Candidate timeout",
  );
  if (timeoutMs > CANDIDATE_TIMEOUT_MS)
    throw new Error("Candidate timeout cannot exceed 45 minutes");
  const evalRoot = resolve(directory, "evals");
  const directories = (await readdir(evalRoot, { withFileTypes: true }))
    .filter((entry) => entry.isDirectory() && !entry.name.startsWith("."))
    .sort((a, b) => a.name.localeCompare(b.name));
  if (!directories.length) throw new Error("Benchmark has no eval folders");
  const evals = await Promise.all(
    directories.map((entry) => loadEval(resolve(evalRoot, entry.name))),
  );
  if (evals.some((item) => item.judge) && !definition.judge?.model)
    throw new Error("A benchmark containing judge.md requires judge.model");
  const concurrency = positive(definition.concurrency, 10, "Concurrency");
  if (concurrency < 2 && evals.some((item) => item.settings.earlyStop))
    throw new Error(
      "Early stopping requires concurrency of at least 2 for eval and judge work",
    );
  const engine = definition.container?.engine ?? "docker";
  if (engine !== "docker" && engine !== "podman")
    throw new Error("Container engine must be docker or podman");
  for (const search of [
    definition.candidate?.websearch,
    definition.judge?.websearch,
  ])
    if (search !== undefined && search !== false && search !== "exa")
      throw new Error("Websearch must be exa or false");

  const name = definition.name ?? basename(directory);

  const dockerfile =
    definition.container?.dockerfile === undefined
      ? undefined
      : contained(
          directory,
          relativePath(definition.container.dockerfile, "container.dockerfile"),
        );

  if (dockerfile && dirname(dockerfile) === directory)
    throw new Error(
      "container.dockerfile must be in a subdirectory, which becomes its build context",
    );

  if (dockerfile && !(await stat(dockerfile).catch(() => undefined))?.isFile())
    throw new Error(`container.dockerfile not found: ${dockerfile}`);

  // Docker tags allow at most 128 characters from [A-Za-z0-9_.-].
  const image =
    definition.container?.image ??
    (dockerfile
      ? `openeval-runtime:${`${OPENCODE_VERSION}-${name}`.replace(/[^\w.-]+/g, "-").slice(0, 128)}`
      : RUNTIME_IMAGE);

  if (dockerfile && image === RUNTIME_IMAGE)
    throw new Error("container.image must differ from the runtime image when container.dockerfile is set");

  return {
    name,
    directory,
    models,
    evals,
    repetitions: positive(definition.repetitions, 3, "Repetitions"),
    concurrency,
    candidate: {
      timeoutMs,
      websearch: definition.candidate?.websearch ?? "exa",
      ...(definition.candidate?.providers
        ? { providers: definition.candidate.providers }
        : {}),
    },
    judge: {
      ...(definition.judge?.model
        ? { model: modelRef(definition.judge.model) }
        : {}),
      timeoutMs: positive(
        definition.judge?.timeoutMs,
        600_000,
        "Judge timeout",
      ),
      websearch: definition.judge?.websearch ?? "exa",
    },
    container: {
      engine,
      image,
      dockerfile,
      cpus: positive(definition.container?.cpus, 2, "CPU count"),
      memoryMiB: positive(definition.container?.memoryMiB, 4096, "Memory"),
    },
  };
}
