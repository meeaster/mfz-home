export const OPENCODE_VERSION = "2.0.14";

export const RUNTIME_IMAGE = `openeval-runtime:${OPENCODE_VERSION}`;
