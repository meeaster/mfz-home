import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-DBQnJ2_M.js";import"./chunk-DU6HZSFF-CQh4KD3x.js";import"./chunk-75Z2AOVW-D72khi3v.js";import"./chunk-PWAF6VOD-DEv_eSHa.js";import"./chunk-GMAD6QVW-CLYAu-CP.js";import"./chunk-P2QGCYS3-DnGKWGRo.js";import"./chunk-4HAMMTFA-C5k0xdRK.js";import"./chunk-GVQU2GXP-y-KZHnOW.js";import"./chunk-OSK3NFVY-CQZIVhGT.js";import"./chunk-F27PBJKO-BIrODOC8.js";import"./chunk-XXDRQBXY-BXtNJg5R.js";import"./chunk-POPQ4Y6H-DQy6bYo2.js";import"./chunk-L3NEJ4N5-2TZVRVkf.js";import{r as t,t as n}from"./chunk-SHT3W25Y-BdbWUIhB.js";import"./mermaid.core-yFiFSKzH.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};