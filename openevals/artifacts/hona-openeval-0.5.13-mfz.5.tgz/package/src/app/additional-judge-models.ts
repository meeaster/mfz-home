import type { EvalDefinition, Judge } from "../types";
import { loadableJudgeModel, type JudgeModelRef } from "../infra/judge-harness/model-ref";

/** Validate judge.additional from benchmark.ts; undefined when none are configured.
 * Only judge.md rubrics have additional judges. */
export function additionalJudgeModels(
  additional: Judge["additional"],
  primary: string | undefined,
  evals: readonly Pick<EvalDefinition, "judge">[],
): JudgeModelRef[] | undefined {
  if (additional === undefined) return undefined;

  if (!Array.isArray(additional))
    throw new Error("judge.additional must be an array of judge models");

  const models: JudgeModelRef[] = [];

  for (const value of additional) {
    const model = loadableJudgeModel(value);

    if (model === primary)
      throw new Error(`judge.additional repeats the primary judge: ${model}`);

    if (models.includes(model))
      throw new Error(`judge.additional contains a duplicate judge: ${model}`);

    models.push(model);
  }

  if (models.length && !evals.some((item) => item.judge))
    throw new Error(
      "judge.additional grades judge.md rubrics; no selected eval has judge.md",
    );

  return models.length ? models : undefined;
}
