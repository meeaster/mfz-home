import type {
  BenchmarkDefinition,
  JudgeRun,
  ModelRef,
  PlanItem,
  Slot,
} from "../types";
import type { Results } from "../infra/sqlite";
import type { ExecutionContext } from "./context";
import type { ExecutionBudget } from "./execution-budget";
import type { CostBudget } from "./cost-plan";
import type { JudgeModelRef } from "../infra/judge-harness/model-ref";
import { judgeFingerprint } from "./input-fingerprints";
import { canJudgeEval } from "./eval-state";
import { judgeEvalRun } from "./judge-run";

/** Additional judges grade the same finalized evidence as the primary judge and are
 * reported separately. They are recorded as ordinary JudgeRuns that no slot selects;
 * their input fingerprint links them to the slot evidence and judge model. */
export type AdditionalJudgeItem = {
  slotId: string;
  evalId: string;
  model: ModelRef;
  repetition: number;
  judge: JudgeModelRef;
  judgeHash: string;
  /** Absent until the slot has finalized, judgeable candidate evidence. */
  evalRunId?: string;
  judgeRunId?: string;
  action: "judge" | "reuse" | "failed" | "running" | "waiting" | "deferred";
  reason: string;
};

/** The judge configuration an additional judge runs with: the primary settings with its own model. */
export const asAdditionalJudge = (
  definition: BenchmarkDefinition,
  model: JudgeModelRef,
): BenchmarkDefinition => ({ ...definition, judge: { ...definition.judge, model } });

/** Matches the primary judge fingerprint for the same model, so equivalent judgments are shared. */
export const additionalJudgeHash = (
  definition: BenchmarkDefinition,
  evalId: string,
  model: JudgeModelRef,
) => judgeFingerprint(asAdditionalJudge(definition, model), evalId);

/** JudgeRuns that graded this evidence with these judge inputs, in recorded order. */
export const judgeRunsFor = (
  judges: ReadonlyMap<string, readonly JudgeRun[]>,
  evalRunId: string,
  judgeHash: string,
) =>
  (judges.get(evalRunId) ?? []).filter(
    (run) => run.input.judgeHash === judgeHash && run.input.mode === "final",
  );

export const latestCompleted = (runs: readonly JudgeRun[]) =>
  runs.findLast((run) => run.state === "completed");

/** Plan additional judgments for these slots. Like the primary judge, a failed judgment
 * needs an explicit retry, but work a stopped runner interrupted is judged again. */
export function planAdditionalJudges(
  definition: BenchmarkDefinition,
  results: Results,
  slots: readonly Slot[],
  options: { stoppedRunner?: boolean } = {},
): AdditionalJudgeItem[] {
  const models = definition.additionalJudges ?? [];

  if (!models.length) return [];

  const judges = Map.groupBy(results.judgeRuns(), (run) => run.input.evalRunId);

  const interrupted = (run: JudgeRun) =>
    !!run.interrupted || (!!options.stoppedRunner && run.state === "running");

  return slots.flatMap((slot) => {
    const rubric = definition.evals.find((item) => item.id === slot.evalId);

    if (!slot.active || !rubric?.judge) return [];

    const candidate = slot.evalRunId
      ? results.evalRun(slot.evalRunId)
      : undefined;

    return models.map((judge): AdditionalJudgeItem => {
      const item = {
        slotId: slot.id,
        evalId: slot.evalId,
        model: slot.model,
        repetition: slot.repetition,
        judge,
        judgeHash: additionalJudgeHash(definition, slot.evalId, judge),
      };

      if (!canJudgeEval(candidate))
        return {
          ...item,
          action: "waiting",
          reason: "Awaiting finalized candidate evidence",
        };

      const runs = judgeRunsFor(judges, candidate.id, item.judgeHash);
      const completed = latestCompleted(runs);

      if (completed)
        return {
          ...item,
          evalRunId: candidate.id,
          judgeRunId: completed.id,
          action: "reuse",
          reason: "Evidence and judge inputs unchanged",
        };

      const running = runs.find(
        (run) => run.state === "running" && !interrupted(run),
      );

      if (running)
        return {
          ...item,
          evalRunId: candidate.id,
          judgeRunId: running.id,
          action: "running",
          reason: "Judging is in progress",
        };

      const failed = runs.findLast((run) => !interrupted(run));

      if (failed)
        return {
          ...item,
          evalRunId: candidate.id,
          judgeRunId: failed.id,
          action: "failed",
          reason: `Judge ${failed.state}; explicit retry required`,
        };

      return {
        ...item,
        evalRunId: candidate.id,
        action: "judge",
        reason: runs.length
          ? "The runner stopped during judging; judging again"
          : "No current judgment from this judge",
      };
    });
  });
}

/** Slots this invocation admitted; deferred work keeps its previous selection. */
export const admittedSlots = (plan: readonly PlanItem[]) =>
  plan.flatMap((item) => (item.action === "deferred" ? [] : [item.slot]));

const median = (values: readonly number[]) => {
  if (!values.length) return null;

  const sorted = values.toSorted((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);

  return sorted.length % 2
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
};

const recordedCosts = (runs: readonly JudgeRun[]) =>
  runs.flatMap((run) => {
    const cost = run.session?.accounting?.costUSD;

    return cost === undefined ? [] : [cost];
  });

/** Median recorded cost of this judge model, else of any judge; null when nothing is recorded. */
function judgeCostEstimate(judges: readonly JudgeRun[], model: JudgeModelRef) {
  return (
    median(recordedCosts(judges.filter((run) => run.input.model === model))) ??
    median(recordedCosts(judges))
  );
}

export type GradeAdditionalJudge = (
  context: ExecutionContext,
  item: AdditionalJudgeItem & { evalRunId: string },
) => Promise<JudgeRun>;

/** Upstream's judging path, run with the additional judge's model and fingerprint. */
const gradeAdditionalJudge: GradeAdditionalJudge = (context, item) => {
  const candidate = context.results.evalRun(item.evalRunId);

  if (!candidate) throw new Error(`Unknown eval run: ${item.evalRunId}`);

  return judgeEvalRun(
    { ...context, definition: asAdditionalJudge(context.definition, item.judge) },
    candidate,
    {},
    item.judgeHash,
  );
};

/** Planned cost of grading these items, or null when any judge has no recorded cost. */
export function estimateAdditionalJudges(
  judges: readonly JudgeRun[],
  items: readonly AdditionalJudgeItem[],
) {
  let total = 0;

  for (const item of items) {
    const estimate = judgeCostEstimate(judges, item.judge);

    if (estimate === null) return null;

    total += estimate;
  }

  return total;
}

/** Grade each item with finalized evidence. Grading failures are recorded on their own
 * JudgeRuns and leave other judges and the primary selection alone. */
export async function gradeAdditionalItems(
  context: ExecutionContext,
  items: readonly AdditionalJudgeItem[],
  budget: ExecutionBudget,
  costBudget: CostBudget,
  grade: GradeAdditionalJudge = gradeAdditionalJudge,
) {
  const judges = context.results.judgeRuns();
  const errors: unknown[] = [];

  await Promise.all(
    items.map(async (item) => {
      const { evalRunId } = item;

      if (!evalRunId) return;

      await budget.run("judge", async () => {
        const release = costBudget.reserve(
          judgeCostEstimate(judges, item.judge),
        );

        if (!release) {
          item.action = "deferred";
          item.reason = "Scheduling cost budget reached or no estimate is available";

          return;
        }

        try {
          const run = await grade(context, { ...item, evalRunId });

          item.judgeRunId = run.id;
          item.reason = `Judge ${run.state}`;
        } catch (error) {
          errors.push(error);
        } finally {
          release();
        }
      });
    }),
  );

  if (errors.length)
    throw new AggregateError(errors, "One or more additional judges failed");
}

/** Judge finalized evidence of admitted slots with each additional judge that lacks a judgment. */
export async function runAdditionalJudges(
  context: ExecutionContext,
  plan: readonly PlanItem[],
  budget: ExecutionBudget,
  costBudget: CostBudget,
  grade: GradeAdditionalJudge = gradeAdditionalJudge,
): Promise<AdditionalJudgeItem[]> {
  const slots = admittedSlots(plan).map(
    (slot) => context.results.slot(slot.id) ?? slot,
  );

  const items = planAdditionalJudges(context.definition, context.results, slots);

  await gradeAdditionalItems(
    context,
    items.filter((item) => item.action === "judge"),
    budget,
    costBudget,
    grade,
  );

  return items;
}
