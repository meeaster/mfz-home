import type { BenchmarkDefinition, JudgeRun, Slot } from "../types";
import type { JudgeModelRef } from "../infra/judge-harness/model-ref";
import {
  judgeHarnessOf,
  type JudgeComparison,
  type JudgeVerdict,
} from "../judge-view";
import { scoresByJudge } from "./judge-scores";
import {
  additionalJudgeHash,
  judgeRunsFor,
  latestCompleted,
} from "./additional-judges";

function verdict(run: JudgeRun | undefined): JudgeVerdict | null {
  if (!run) return null;

  const scores: JudgeVerdict["scores"] = {};

  for (const [id, score] of Object.entries(run.judgment?.scores ?? {}))
    scores[id] = { value: score.value, reason: score.reason };

  return {
    judgeRunId: run.id,
    state: run.state,
    value: run.judgment?.value ?? null,
    scores,
  };
}

/** Per-judge scores and each active EvalRun's judgment from every judge, for the viewer. */
export function judgeComparison(
  definition: BenchmarkDefinition,
  slots: readonly Slot[],
  judges: readonly JudgeRun[],
  evalId?: string,
): JudgeComparison {
  const index = new Map(judges.map((run) => [run.id, run]));

  const byEvidence = Map.groupBy(judges, (run) => run.input.evalRunId);

  const perJudge = scoresByJudge(definition, slots, judges, evalId);

  // Code-only evals have no LLM judge; every judge reports their judge.ts JudgeRun, as in scoresByJudge.
  const codeOnly = (id: string) =>
    !definition.evals.find((item) => item.id === id)?.judge;

  const judgeRunOf = (
    slot: Slot,
    model: JudgeModelRef | undefined,
    primary: boolean,
  ) => {
    if ((primary || codeOnly(slot.evalId)) && slot.judgeRunId)
      return index.get(slot.judgeRunId);

    if (!slot.evalRunId) return undefined;

    const hash =
      primary || !model
        ? slot.judgeHash
        : additionalJudgeHash(definition, slot.evalId, model);

    const runs = judgeRunsFor(byEvidence, slot.evalRunId, hash);

    return latestCompleted(runs) ?? runs.at(-1);
  };

  return {
    judges: perJudge.map((judge) => ({
      ref: judge.judge,
      harness: judge.judge ? judgeHarnessOf(judge.judge) : "opencode",
      primary: judge.primary,
      scores: judge.scores,
    })),
    evalRuns: slots.flatMap((slot) =>
      slot.active && (!evalId || slot.evalId === evalId)
        ? [
            {
              slotId: slot.id,
              evalId: slot.evalId,
              model: slot.model,
              repetition: slot.repetition,
              evalRunId: slot.evalRunId ?? undefined,
              verdicts: perJudge.map((judge) =>
                verdict(judgeRunOf(slot, judge.judge, judge.primary)),
              ),
            },
          ]
        : [],
    ),
  };
}
