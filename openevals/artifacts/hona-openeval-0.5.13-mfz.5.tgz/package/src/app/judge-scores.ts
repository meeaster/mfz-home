import { resolve } from "node:path";
import type { BenchmarkDefinition, JudgeRun, Slot } from "../types";
import type { JudgeModelRef } from "../infra/judge-harness/model-ref";
import { Results } from "../infra/sqlite";
import { benchmarkScores } from "./scores";
import {
  additionalJudgeHash,
  judgeRunsFor,
  latestCompleted,
} from "./additional-judges";

/** One judge's benchmark scores. Judges are never averaged together. */
export type JudgeScores = {
  judge: JudgeModelRef | undefined;
  primary: boolean;
  scores: ReturnType<typeof benchmarkScores>;
};

/** Scores per judge, optionally for one eval, computed by the primary scoring rules over each judge's own judgments.
 * Code-only evals have no LLM judge, so every judge reports their recorded judge.ts scores. */
export function scoresByJudge(
  definition: BenchmarkDefinition,
  slots: readonly Slot[],
  judges: readonly JudgeRun[],
  evalId?: string,
): JudgeScores[] {
  const byEvidence = Map.groupBy(judges, (run) => run.input.evalRunId);

  const selectedBy = (model: JudgeModelRef, slot: Slot): Slot => {
    const rubric = definition.evals.find((item) => item.id === slot.evalId);

    if (!rubric?.judge) return slot;

    const judgeHash = additionalJudgeHash(definition, slot.evalId, model);

    const judgment = slot.evalRunId
      ? latestCompleted(judgeRunsFor(byEvidence, slot.evalRunId, judgeHash))
      : undefined;

    return { ...slot, judgeRunId: judgment?.id ?? null };
  };

  return [
    {
      judge: definition.judge.model,
      primary: true,
      scores: benchmarkScores(definition, slots, judges, evalId),
    },
    ...(definition.additionalJudges ?? []).map((model) => ({
      judge: model,
      primary: false,
      scores: benchmarkScores(
        definition,
        slots.map((slot) => selectedBy(model, slot)),
        judges,
        evalId,
      ),
    })),
  ];
}

/** Read-only per-judge scores for a BenchmarkRun directory. */
export function readJudgeScores(directory: string) {
  using results = new Results(resolve(directory, "runner.db"), true);

  return results.readSnapshot(() => {
    const benchmark = results.benchmark;

    if (!benchmark) throw new Error("No benchmark run in this directory");

    return {
      benchmark: benchmark.id,
      judges: scoresByJudge(
        benchmark.definition,
        results.slots(),
        results.judgeRuns(),
      ),
    };
  });
}
