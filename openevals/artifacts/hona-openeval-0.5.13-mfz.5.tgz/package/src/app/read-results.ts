import { readdir, realpath } from "node:fs/promises";
import { resolve, dirname, sep } from "node:path";
import { Results } from "../infra/sqlite";
import type { BenchmarkRun, EvalRun, JudgeRun, Slot, Cost } from "../types";
import type {
  ResultEntry,
  ResultIndex,
  ResultSummary,
  EvalRunIndex,
  EvalRunSummary,
  ActivityRun,
  LiveEvalRun,
  StageState,
  StageStatus,
  JudgeAudit,
} from "../view";
import { categoryCatalog, sumCosts } from "../view";
import { benchmarkScores } from "./scores";
import { executionRuntime } from "./execution-runtime";
import {
  mergeRuntime,
  runtimeMs,
  runtimeClock,
  timestampMs,
  type RuntimeInterval,
} from "../runtime";
import { canJudgeEval } from "./eval-state";
import { CandidateEvidence, type EvidenceQuery } from "../infra/evidence";
import { contained, hash } from "../infra/files";
import { judgeComparison } from "./judge-comparison";

const scheduled = (slot: Slot, benchmark: BenchmarkRun, now: number) =>
  benchmark.state === "running" &&
  now - Date.parse(benchmark.updatedAt) <= 30_000 &&
  benchmark.scheduledSlotIds.includes(slot.id);

const costOf = (run: EvalRun | JudgeRun, results?: Results): Cost => {
  if ("evalRunId" in run.input && run.input.kind === "code")
    return { usd: 0, reportedUSD: 0, complete: true };
  const accounting = run.session?.accounting;

  // A subscription reports $0; its models.dev list price stands in.
  if (accounting?.costUSD === 0 && accounting.estimate)
    return {
      usd: accounting.estimate.usd,
      reportedUSD: accounting.estimate.usd,
      complete: true,
      estimated: true,
    };
  const usd = accounting?.costUSD;
  return {
    usd: usd ?? null,
    reportedUSD: usd ?? results?.recordedCost(run.id) ?? 0,
    complete: usd !== undefined,
  };
};
// Restored records represent the same original execution, not additional model spend.
const runCosts = (runs: (EvalRun | JudgeRun)[], results: Results) => {
  const unique = new Map(runs.map((run) => [run.id, run]));
  const executions = new Map<string, EvalRun | JudgeRun>();
  for (const run of unique.values()) {
    const restoration = "restoration" in run ? run.restoration : undefined;
    const key = restoration?.evalRunId ?? run.id;
    const previous = executions.get(key);
    if (!previous || restoration) executions.set(key, run);
  }
  return sumCosts([...executions.values()].map((run) => costOf(run, results)));
};
const entryOf = (
  run: BenchmarkRun,
  id = run.id,
  evalId?: string,
): ResultEntry => ({
  id,
  kind: evalId ? "eval" : "benchmark",
  name: evalId
    ? (run.definition.evals.find((item) => item.id === evalId)?.name ?? evalId)
    : run.name,
  ...(!evalId && run.definition.suite ? { suite: run.definition.suite } : {}),
  status: run.state,
  startedAt: run.createdAt,
  updatedAt: Date.parse(run.updatedAt),
  models: run.definition.models.length,
  evals: evalId ? 1 : run.definition.evals.length,
});
export const evalResultId = (benchmarkId: string, evalId: string) =>
  `${benchmarkId}~${encodeURIComponent(evalId)}`;

/** Read-only, typed results access shared by the CLI and viewer API. */
export class ResultReader {
  private paths = new Map<string, string>();
  private runtimes = new Map<string, RuntimeInterval[]>();
  private finishedJudges = new Map<string, Map<string, JudgeRun>>();
  constructor(readonly root: string) {}
  /** Every judge run; parses only running or unseen records, since finalized runs never change. */
  private judgeRunsOf(results: Results) {
    const cache =
      this.finishedJudges.get(results.path) ?? new Map<string, JudgeRun>();
    this.finishedJudges.set(results.path, cache);
    return results.judgeRunStates().flatMap(({ id }) => {
      const cached = cache.get(id);
      if (cached) return [cached];
      const run = results.judgeRun(id);
      if (!run) return [];
      if (run.state !== "running") cache.set(id, run);
      return [run];
    });
  }
  private runtime(
    run: EvalRun | JudgeRun,
    results: Results,
    benchmark: BenchmarkRun,
    now: number,
    candidate?: EvalRun,
    judges?: readonly JudgeRun[],
  ) {
    const key = `${results.path}:${run.id}`;
    const cached = this.runtimes.get(key);
    if (cached) return cached;
    let current = true;
    if (run.state === "running") {
      const slot = candidate ? results.slot(candidate.slotId) : undefined;
      current =
        !!slot &&
        slot.evalRunId === candidate?.id &&
        scheduled(slot, benchmark, now);
      if (current && "evalRunId" in run.input)
        current =
          (judges ?? this.judgeRunsOf(results))
            .filter(
              (judge) =>
                judge.input.evalRunId === candidate!.id &&
                judge.input.judgeHash === slot!.judgeHash,
            )
            .at(-1)?.id === run.id;
    }
    const intervals = executionRuntime(run, results, benchmark, now, current);
    if (run.completedAt) this.runtimes.set(key, intervals);
    return intervals;
  }
  async index(): Promise<ResultIndex> {
    const entries: ResultEntry[] = [],
      warnings: string[] = [];
    const paths = new Map<string, string>();
    const aliases = new Map<string, string>();
    for (const directory of await readdir(this.root, {
      withFileTypes: true,
    }).catch(() => [])) {
      if (!directory.isDirectory()) continue;
      const path = resolve(this.root, directory.name, "runner.db");
      if (!(await Bun.file(path).exists())) continue;
      try {
        using results = new Results(path, true);
        const run = results.benchmark;
        if (!run) continue;
        if (run.mergedInto) {
          aliases.set(run.id, run.mergedInto);
          continue;
        }
        paths.set(run.id, path);
        entries.push(entryOf(run));
      } catch (error) {
        warnings.push(`${directory.name}: ${String(error)}`);
      }
    }
    entries.sort((a, b) => b.startedAt.localeCompare(a.startedAt));
    for (let pass = 0; pass < aliases.size; pass++)
      for (const [id, target] of aliases)
        if (paths.has(target)) paths.set(id, paths.get(target)!);
    this.paths = paths;
    return { public: false, root: this.root, entries, warnings };
  }
  private async database(id: string) {
    const benchmarkId = id.split("~")[0];
    if (!this.paths.has(benchmarkId)) await this.index();
    const path = this.paths.get(benchmarkId);
    if (!path) throw new Error("Unknown benchmark run");
    return new Results(path, true);
  }
  async recording(benchmarkId: string, executionId: string) {
    const results = await this.database(benchmarkId);
    const read = () =>
      results.evalRun(executionId) ?? results.judgeRun(executionId);
    if (!read()) {
      results.close();
      throw new Error("Unknown execution");
    }
    return {
      directory: dirname(results.path),
      read,
      events: (after: number) => results.events(executionId, after),
      close: () => results.close(),
    };
  }
  async judgeAudit(
    benchmarkId: string,
    judgeRunId: string,
  ): Promise<JudgeAudit> {
    using results = await this.database(benchmarkId);
    const judge = results.judgeRun(judgeRunId);
    if (!judge) throw new Error("Unknown judge run");
    const candidate = results.evalRun(judge.input.evalRunId);
    const criteria = new Map(
      [...judge.input.criteria, ...judge.input.codeCriteria ?? []].map((criterion) => [criterion.id, criterion]),
    );
    for (const id of Object.keys(judge.judgment?.scores ?? {}))
      if (!criteria.has(id))
        criteria.set(id, { id, name: id.replaceAll("_", " ") });
    const log = async (path?: string) =>
      path
        ? (
            await Bun.file(contained(dirname(results.path), path))
              .text()
              .catch(() => "")
          ).slice(0, 40_000)
        : undefined;
    return {
      judge: {
        id: judge.id,
        state: judge.state,
        activity: judge.activity,
        decisionCheckId: judge.decisionCheckId,
        monitorError: judge.monitorError,
        monitorErrorAt: judge.monitorErrorAt,
        monitorLimit: judge.monitorLimit,
        judgment: judge.judgment,
        code: judge.code,
        error: judge.error,
      },
      kind: judge.input.kind,
      criteria: [...criteria.values()],
      metrics: candidate?.metrics ?? judge.code?.metrics,
      codeSource: judge.input.code?.source,
      codeStdout: await log(judge.code?.stdout),
      codeStderr: await log(judge.code?.stderr),
      stop: results.evalRun(judge.input.evalRunId)?.stop,
      checks: results.judgeChecks(judgeRunId).map((check) => {
        const start = timestampMs(check.executionStartedAt);
        const end =
          timestampMs(check.completedAt) ??
          runtimeClock(
            Date.now(),
            results.benchmark?.updatedAt,
            results.benchmark?.state === "running",
          );
        return {
          ...check,
          runtimeMs: start === undefined ? 0 : Math.max(0, end - start),
        };
      }),
      history: results
        .judgeRuns()
        .filter((run) => run.input.evalRunId === judge.input.evalRunId)
        .map((run) => ({
          id: run.id,
          state: run.state,
          startedAt: run.startedAt,
          mode: run.input.mode,
          model: run.input.model,
        })),
    };
  }
  /** Each judge's scores and judgments of the active EvalRuns, for a benchmark or one eval. */
  async judges(id: string) {
    using results = await this.database(id);

    const evalId = id.includes("~")
      ? decodeURIComponent(id.slice(id.indexOf("~") + 1))
      : undefined;

    const [slots, judges] = results.readSnapshot(
      () => [results.slots(), this.judgeRunsOf(results)] as const,
    );

    return judgeComparison(results.benchmark!.definition, slots, judges, evalId);
  }
  async verificationEvidence(benchmarkId: string, judgeRunId: string, id: string, path?: string) {
    using results = await this.database(benchmarkId);
    const judge = results.judgeRun(judgeRunId);
    const verification = judge?.code?.verifications?.find(item => item.id === id);
    if (!verification) throw new Error("Unknown verification");
    if (!path) return { receipt: verification };
    const artifact = verification.artifacts.find(item => item.path === path);
    const file = path === "stdout" ? verification.stdout : path === "stderr" ? verification.stderr : artifact?.file;
    if (!file) throw new Error("Unknown verification artifact");
    const root = await realpath(dirname(results.path));
    const target = await realpath(contained(root, file));
    if (target !== root && !target.startsWith(root + sep)) throw new Error("Verification artifact leaves its run directory");
    const bytes = await Bun.file(target).bytes();
    if (bytes.length > 32 * 1024 * 1024 || (artifact && hash(bytes) !== artifact.sha256))
      throw new Error("Verification artifact is too large or its hash differs");
    return { bytes, path };
  }
  async checkEvidence(
    benchmarkId: string,
    judgeRunId: string,
    checkId: string,
    query: EvidenceQuery,
  ) {
    using results = await this.database(benchmarkId);
    const check = results
      .judgeChecks(judgeRunId)
      .find((item) => item.id === checkId);
    const judge = results.judgeRun(judgeRunId);
    if (!judge || (checkId && !check)) throw new Error("Unknown judge check");
    const reference = check?.checkpoint ?? judge.input.evidence;
    const evidence = await CandidateEvidence.open(
      resolve(dirname(results.path), reference.directory),
      reference.hash,
    );
    return evidence.query(query);
  }
  async summary(id: string): Promise<ResultSummary> {
    using results = await this.database(id);
    const run = results.benchmark!,
      evalId = id.includes("~")
        ? decodeURIComponent(id.slice(id.indexOf("~") + 1))
        : undefined;
    const evals = run.definition.evals.filter(
      (item) => !evalId || item.id === evalId,
    );
    if (!evals.length) throw new Error("Unknown eval");
    const [slots, allJudges] = results.readSnapshot(
      () => [results.slots(), this.judgeRunsOf(results)] as const,
    );
    const scores = benchmarkScores(run.definition, slots, allJudges, evalId);
    // Runtime and cost describe the work behind the active selections, not retired history.
    const active = new Set(
      slots.filter((slot) => slot.active).map((slot) => slot.id),
    );
    const candidates = results
      .evalRuns()
      .filter((candidate) => active.has(candidate.slotId));
    const now = Date.now(),
      candidateIndex = new Map(candidates.map((run) => [run.id, run]));
    const evalRuntime = new Map<string, RuntimeInterval[]>();
    for (const execution of [...candidates, ...allJudges]) {
      const candidate =
        "evalRunId" in execution.input
          ? candidateIndex.get(execution.input.evalRunId)
          : (execution as EvalRun);
      if (!candidate) continue;
      const intervals = evalRuntime.get(candidate.input.evalId) ?? [];
      intervals.push(
        ...this.runtime(execution, results, run, now, candidate, allJudges),
      );
      evalRuntime.set(candidate.input.evalId, intervals);
    }
    for (const [id, intervals] of evalRuntime)
      evalRuntime.set(id, mergeRuntime(intervals));
    const runtime = mergeRuntime(
      evalId
        ? (evalRuntime.get(evalId) ?? [])
        : [...evalRuntime.values()].flat(),
    );
    const evalCosts = Object.fromEntries(
      run.definition.evals.map((evalDefinition) => {
        const runs = candidates.filter(
            (candidate) => candidate.input.evalId === evalDefinition.id,
          ),
          ids = new Set(runs.map((candidate) => candidate.id));
        return [
          evalDefinition.id,
          runCosts(
            [
              ...runs,
              ...allJudges.filter((judge) => ids.has(judge.input.evalRunId)),
            ],
            results,
          ),
        ];
      }),
    );
    return {
      entry: entryOf(run, id, evalId),
      overview: {
        name: evalId ? evals[0].name : run.name,
        ...(!evalId && run.definition.suite
          ? { suite: run.definition.suite }
          : {}),
        kind: evalId ? "eval" : "benchmark",
        status: run.state,
        startedAt: run.createdAt,
        completedAt: run.state === "running" ? undefined : run.completedAt,
        scores,
        evals: evals.map((item) => item.id),
        evalNames: Object.fromEntries(
          evals.map((item) => [item.id, item.name]),
        ),
        modelNames: run.modelNames ?? {},
        categories: categoryCatalog(scores[0]?.components ?? []),
        cost: evalId ? evalCosts[evalId] : sumCosts(Object.values(evalCosts)),
        evalCosts,
        runtime,
      },
      durationMs: runtimeMs(runtime, now),
      related: run.definition.evals.map((item) => ({
        id: evalResultId(run.id, item.id),
        eval: item.id,
        status: run.state,
        runtime: evalRuntime.get(item.id) ?? [],
        durationMs: runtimeMs(evalRuntime.get(item.id) ?? [], now),
      })),
    };
  }
  async evalRuns(id: string): Promise<EvalRunIndex> {
    const split = id.indexOf("~");
    if (split < 0) throw new Error("Select an eval");
    const evalId = decodeURIComponent(id.slice(split + 1));
    using results = await this.database(id);
    const benchmark = results.benchmark!;
    return {
      entry: entryOf(benchmark, id, evalId),
      eval: evalId,
      benchmarkId: benchmark.id,
      runs: this.liveRuns(results, [evalId]).get(evalId)!,
    };
  }
  /** Active slot rows for the requested evals, from one read of the store. */
  private liveRuns(results: Results, evalIds: readonly string[]) {
    const benchmark = results.benchmark!,
      executions = results.evalRuns(),
      judges = this.judgeRunsOf(results),
      now = Date.now();
    const byId = new Map(executions.map((run) => [run.id, run]));
    const bySlot = Map.groupBy(executions, (run) => run.slotId);
    const judgesFor = Map.groupBy(judges, (run) => run.input.evalRunId);
    const out = new Map<string, EvalRunSummary[]>(
      evalIds.map((evalId) => [evalId, []]),
    );
    for (const slot of results.slots()) {
      const rows = out.get(slot.evalId);
      if (!slot.active || !rows) continue;
      const candidate = slot.evalRunId ? byId.get(slot.evalRunId) : undefined;
      const current = liveRun(
        slot,
        candidate,
        candidate ? (judgesFor.get(candidate.id) ?? []) : [],
        benchmark,
        results,
        (run) => this.runtime(run, results, benchmark, now, candidate, judges),
      );
      const related = bySlot.get(slot.id) ?? [];
      rows.push({
        ...current,
        cost: runCosts(
          [...related, ...related.flatMap((run) => judgesFor.get(run.id) ?? [])],
          results,
        ),
        elapsedMs: runtimeMs(
          [...current.eval.runtime, ...current.judge.runtime],
          now,
        ),
      });
    }
    return out;
  }
  async activity(): Promise<ActivityRun[]> {
    const index = await this.index(),
      out: ActivityRun[] = [];
    for (const entry of index.entries) {
      const summary = await this.summary(entry.id);
      using results = await this.database(entry.id);
      const benchmark = results.benchmark!;
      const live = this.liveRuns(
        results,
        benchmark.definition.evals.map((item) => item.id),
      );
      for (const [
        evalOrder,
        evalDefinition,
      ] of benchmark.definition.evals.entries()) {
        const id = evalResultId(benchmark.id, evalDefinition.id);
        out.push({
          id,
          benchmarkId: benchmark.id,
          resultId: id,
          cost: summary.overview.evalCosts[evalDefinition.id],
          state: {
            id,
            eval: evalDefinition.id,
            benchmark: benchmark.id,
            name: benchmark.name,
            ...(benchmark.definition.suite
              ? { suite: benchmark.definition.suite }
              : {}),
            startedAt: benchmark.createdAt,
            heartbeatAt: benchmark.updatedAt,
            status: benchmark.state,
            concurrency: benchmark.definition.concurrency,
            evalOrder,
            runs: live.get(evalDefinition.id)!,
            runtime: summary.related.find(
              (item) => item.eval === evalDefinition.id,
            )!.runtime,
            ...(benchmark.execution
              ? {
                  invocation: {
                    startedAt: benchmark.execution.startedAt,
                    spentUSD: benchmark.execution.spentUSD,
                  },
                }
              : {}),
          },
        });
      }
    }
    return out;
  }
}

function stageState(
  run: EvalRun | JudgeRun | undefined,
  stale: boolean,
  waitingStatus: StageStatus,
  results: Results,
  runtime: RuntimeInterval[],
): StageState {
  if (!run) return { status: waitingStatus, runtime };
  const status: StageStatus =
    run.state === "running"
      ? stale
        ? "interrupted"
        : "activity" in run && run.activity === "watching"
          ? "watching"
          : "activity" in run && run.activity === "queued"
            ? "queued"
            : "in_progress"
      : run.state === "completed"
        ? "completed"
        : run.state === "stopped"
          ? "stopped"
          : run.state === "timed_out"
            ? "timed_out"
            : run.state === "cost_limited"
              ? "cost_limited"
              : "failed";
  return {
    executionId: run.id,
    status,
    startedAt: run.startedAt,
    completedAt: run.completedAt,
    elapsedMs: runtimeMs(runtime, Date.now()),
    runtime,
    cost: costOf(run, results),
    message: run.error,
    ...("kind" in run.input ? { kind: run.input.kind } : {}),
  };
}

function liveRun(
  slot: Slot,
  candidate: EvalRun | undefined,
  judges: JudgeRun[],
  benchmark: BenchmarkRun,
  results: Results,
  runtime: (run: EvalRun | JudgeRun) => RuntimeInterval[],
): LiveEvalRun {
  const judge = judges
    .filter(
      (run) =>
        run.input.evalRunId === candidate?.id &&
        run.input.judgeHash === slot.judgeHash,
    )
    .at(-1);
  const executing = judge ?? candidate;
  const stale =
    benchmark.state === "running" &&
    Date.now() - Date.parse(benchmark.updatedAt) > 30_000;
  const judgeReady = canJudgeEval(candidate);
  const stage = judge || judgeReady ? "judge" : "candidate";
  const status: LiveEvalRun["status"] =
    executing?.state === "running"
      ? stale
        ? "interrupted"
        : "in_progress"
      : executing &&
          ["failed", "timed_out", "cost_limited"].includes(executing.state) &&
          (judge || !judgeReady)
        ? "failed"
        : slot.judgeRunId
          ? "completed"
          : "queued";
  const evalStage = stageState(
    candidate,
    stale,
    "queued",
    results,
    candidate ? runtime(candidate) : [],
  );
  const judgeBlocked =
    !judgeReady &&
    ["completed", "failed", "timed_out", "cost_limited", "interrupted"].includes(
      evalStage.status,
    );
  const judgeStage: StageState = {
    kind: benchmark.definition.evals.find((item) => item.id === slot.evalId)
      ?.code
      ? benchmark.definition.evals.find((item) => item.id === slot.evalId)
          ?.judge
        ? "hybrid"
        : "code"
      : "llm",
    ...stageState(
      judge,
      stale,
      judgeBlocked ? "blocked" : judgeReady ? "queued" : "waiting",
      results,
      judge ? runtime(judge) : [],
    ),
    ...(!judge && judgeBlocked
      ? {
          message:
            "Blocked: no finalized eval evidence is available. Retry the eval before judging.",
        }
      : {}),
    ...(judge?.state === "completed"
      ? {
          score: judge.judgment?.value ?? null,
          scores: judge.judgment?.scores,
        }
      : {}),
  };
  const attention = ["failed", "timed_out", "cost_limited", "interrupted"].includes(
    evalStage.status,
  )
    ? `Eval run ${evalStage.status.replaceAll("_", " ")}: ${candidate?.error ?? "no error recorded"}`
    : ["failed", "timed_out", "interrupted"].includes(judgeStage.status)
      ? `Judge ${judgeStage.status.replaceAll("_", " ")}: ${judge?.error ?? "no error recorded"}`
      : judgeStage.score === null
        ? `Unscored: ${judge?.judgment?.reason ?? "the judge returned no decision"}`
        : undefined;
  return {
    id: slot.id,
    evalRunId: candidate?.id,
    judgeRunId: judge?.id,
    model: slot.model.split("#")[0],
    reasoning: slot.model.split("#")[1] ?? "default",
    repetition: slot.repetition,
    status,
    stage,
    startedAt: executing?.startedAt,
    completedAt: executing?.completedAt,
    message: executing?.error,
    eval: evalStage,
    judge: judgeStage,
    attention,
    earlyStop: candidate
      ? !!candidate.input.earlyStop
      : !!benchmark.definition.evals.find((item) => item.id === slot.evalId)
          ?.settings.earlyStop,
    stop: candidate?.stop,
    scheduled: scheduled(slot, benchmark, Date.now()),
  };
}
