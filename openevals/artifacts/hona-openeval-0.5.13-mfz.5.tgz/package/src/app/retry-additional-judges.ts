import { resolve } from "node:path";
import type { BenchmarkDefinition, ExecutionObserver, Slot } from "../types";
import type { JudgeModelRef } from "../infra/judge-harness/model-ref";
import { Results } from "../infra/sqlite";
import { judgingFingerprint } from "../infra/judging";
import { verificationRuntime } from "../infra/verification/image";
import { ExecutionBudget } from "./execution-budget";
import { CostBudget } from "./cost-plan";
import { finishBenchmark } from "./run-benchmark";
import { recoverStoppedRunner, runnerStopped } from "./recover-run";
import {
  estimateAdditionalJudges,
  gradeAdditionalItems,
  planAdditionalJudges,
  type AdditionalJudgeItem,
  type GradeAdditionalJudge,
} from "./additional-judges";

export type RetryAdditionalJudgesOptions = {
  /** Only these active EvalRuns; each must have a failed additional judgment in scope. */
  evalRunIds?: readonly string[];
  /** Only these additional judge models. */
  judges?: readonly JudgeModelRef[];
  /** Stop admitting work when reported spend plus reservations reaches this amount. */
  maxCostUSD?: number;
  dryRun?: boolean;
  onEvent?: ExecutionObserver;
  grade?: GradeAdditionalJudge;
};

const unique = <T>(values: readonly T[], label: string) => {
  if (!values.length || new Set(values).size !== values.length)
    throw new Error(`Select unique ${label}`);

  return new Set(values);
};

/** Active slots, narrowed to the selected EvalRuns. */
function selectedSlots(results: Results, evalRunIds: readonly string[] | undefined) {
  const active = results.slots().filter((slot) => slot.active);

  if (!evalRunIds) return active;

  const selected = unique(evalRunIds, "EvalRun IDs to retry");
  const slots = active.filter((slot) => slot.evalRunId && selected.has(slot.evalRunId));

  if (slots.length !== selected.size)
    throw new Error("Select the active EvalRun for each repetition");

  return slots;
}

/** Failed additional judgments in scope. Interrupted work is judged again by `run`;
 * completed judgments, the primary judge, and candidates are never selected. */
function retryPlan(
  definition: BenchmarkDefinition,
  results: Results,
  slots: readonly Slot[],
  options: Pick<RetryAdditionalJudgesOptions, "evalRunIds" | "judges">,
  stoppedRunner: boolean,
): AdditionalJudgeItem[] {
  const configured = definition.additionalJudges ?? [];
  const judges = options.judges && unique(options.judges, "additional judges");

  for (const judge of judges ?? [])
    if (!configured.includes(judge))
      throw new Error(`Not an additional judge of this run: ${judge}`);

  const plan = planAdditionalJudges(definition, results, slots, { stoppedRunner }).filter(
    (item) => item.action === "failed" && (!judges || judges.has(item.judge)),
  );

  for (const evalRunId of options.evalRunIds ?? [])
    if (!plan.some((item) => item.evalRunId === evalRunId))
      throw new Error(`No failed additional judgment to retry for ${evalRunId}`);

  return plan.map((item) => ({
    ...item,
    action: "judge",
    reason: "Explicit retry of a failed additional judgment",
  }));
}

/** Judge failed additional judgments again over their recorded evidence. Uses the saved
 * benchmark definition, so retried judgments keep the fingerprints of the failed ones. */
export async function retryAdditionalJudges(
  directory: string,
  options: RetryAdditionalJudgesOptions = {},
): Promise<AdditionalJudgeItem[]> {
  using results = new Results(resolve(directory, "runner.db"), options.dryRun);
  const saved = results.benchmark;

  if (!saved) throw new Error("No benchmark run in this directory");

  if (saved.mergedInto)
    throw new Error(`This run was merged into ${saved.mergedInto}; use the aggregate run`);

  const stopped = saved.state === "running";

  if (stopped && !runnerStopped(saved))
    throw new Error("Wait for the active benchmark run");

  // Validate the budget before recovery or any selection change.
  new CostBudget(options.maxCostUSD, () => 0);

  const plan = retryPlan(
    saved.definition,
    results,
    selectedSlots(results, options.evalRunIds),
    options,
    stopped,
  );

  if (options.dryRun || !plan.length) return plan;

  if (stopped) recoverStoppedRunner(results);

  const definition = saved.definition;

  const runtime = {
    ...saved.runtime,
    judgeHash: await judgingFingerprint(),
    verification: await verificationRuntime(definition.judge.verification),
  };

  const existing = new Set(
    [...results.evalRuns(), ...results.judgeRuns()].map((run) => run.id),
  );

  const spent = () =>
    results
      .judgeRuns()
      .filter((run) => !existing.has(run.id))
      .reduce(
        (sum, run) =>
          sum + (run.session?.accounting?.costUSD ?? results.recordedCost(run.id) ?? 0),
        0,
      );

  const deferred = () => plan.filter((item) => item.action === "deferred").length;
  const startedAt = new Date().toISOString();

  results.transaction(() => {
    if (results.benchmark?.state === "running")
      throw new Error("Another operation claimed this benchmark run");

    results.saveBenchmark({
      ...saved,
      runtime,
      state: "running",
      scheduledSlotIds: [...new Set(plan.map((item) => item.slotId))],
      updatedAt: startedAt,
      execution: {
        startedAt,
        onlyModels: [...new Set(plan.map((item) => item.model))],
        onlyEvals: [...new Set(plan.map((item) => item.evalId))],
        onlyRepetitions: [...new Set(plan.map((item) => item.repetition))],
        budgetUSD: options.maxCostUSD,
        estimatedUSD: estimateAdditionalJudges(results.judgeRuns(), plan),
        spentUSD: 0,
        deferred: 0,
      },
    });
  });

  const progress = () => {
    const current = results.benchmark;

    if (current)
      results.saveBenchmark({
        ...current,
        updatedAt: new Date().toISOString(),
        execution: { ...current.execution, spentUSD: spent(), deferred: deferred() },
      });
  };

  const context = {
    directory: resolve(directory),
    definition,
    runtime,
    results,
    onEvent: options.onEvent,
  };

  const heartbeat = setInterval(progress, 5000);

  try {
    await gradeAdditionalItems(
      context,
      plan,
      new ExecutionBudget(definition.concurrency),
      new CostBudget(options.maxCostUSD, spent),
      options.grade,
    );

    return plan;
  } finally {
    clearInterval(heartbeat);
    progress();
    finishBenchmark(context);
  }
}
