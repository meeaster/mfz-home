#!/usr/bin/env bun
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import {
  runBenchmark,
  loadBenchmark,
  buildImage,
  addModels,
  removeModels,
  retryEvalRuns,
  planEvalRunRetries,
  restoreEvalRun,
  judgeRun,
  serveResults,
  mergeBenchmarkRuns,
  snapshotBenchmarkRun,
  buildVerificationImage,
  VERIFICATION_IMAGE,
  prepareInputs,
  refreshModelNames,
  readJudgeScores,
  retryAdditionalJudges,
} from "./index";
import type { ModelRef } from "./index";

const args = process.argv.slice(2),
  command = args[0] ?? "run";
const option = (flag: string) => {
  const index = args.indexOf(flag);
  return index >= 0 ? args[index + 1] : undefined;
};
const models = (flag = "--model") =>
  args.flatMap((arg, index) =>
    arg === flag ? [args[index + 1] as ModelRef] : [],
  );
const benchmark = resolve(
  option("--benchmark") ?? process.cwd(),
);
try {
  if (command === "--help" || command === "help" || args.includes("--help")) {
    console.log(`Usage: openeval <command> [options]

Commands:
  image                 Build the candidate container image
  plan                  Show missing or changed work without executing it
  prepare               Prepare and archive inputs without model calls
  run                   Execute missing or changed work in the current result
  view                  Serve the results viewer
  snapshot <run> <name>  Export a score snapshot
  merge-runs <to> <from> Merge results into one aggregate
  add-models <run>       Add models with repeated --model flags
  remove-models <run>    Remove active models while retaining their evidence
  refresh-model-names <run> Refresh reporting names without running evals
  retry <run> <eval-run>... Retry failed or unresolved candidate work
  rejudge <run> <eval-run> Judge the saved evidence again
  judge-scores <run>     Show scores from each judge separately
  retry-additional-judges <run> [eval-run...] Retry failed additional judgments
  restore <run> <eval-run> Restore completed orphan work from hashed backups

Options:
  --benchmark <dir>      Benchmark directory (default: current directory)
  --run <dir>            Resume a specific result directory
  --new                 Start a new result
  --model <provider/id>  Model to add or remove (repeatable)
  --only-model <ref>     Execute only this model (repeatable)
  --only-eval <id>       Execute only this eval (repeatable)
  --only-category <name> Execute only evals with criteria in this category (repeatable)
  --only-repetition <n>  Execute only this repetition (repeatable)
  --max-cost <usd>       Scheduling budget for this invocation
  --final-only          Judge only after candidates finish
  --judge <ref>          Additional judge to retry (repeatable)
  --dry-run             Plan explicit retries without running them
  --verification        Build only the standard verification image (image command)
  --output <dir>         New prepared-input directory (prepare command)
  --port <port>         Viewer port (default: 4173)
  --database <file>      Native backup for restore
  --database-hash <sha>  SHA-256 of the native backup
  --workspace-archive <file> Workspace tar backup for restore
  --workspace-archive-hash <sha> SHA-256 of the workspace tar

Requires Bun 1.4.2+, Docker, and an authenticated OpenCode installation.`);
  } else if (command === "--version") {
    console.log((await Bun.file(new URL("../package.json", import.meta.url)).json()).version);
  } else if (command === "image") {
    const definition = await loadBenchmark(benchmark);
    if (!args.includes("--verification")) {
      await buildImage(definition.container);
      console.log("Candidate image ready");
    }
    const verification = definition.judge.verification ?? (args.includes("--verification")
      ? { image: VERIFICATION_IMAGE, engine: definition.container.engine } : undefined);
    if (verification) {
      await buildVerificationImage(verification);
      console.log("Verification image ready");
    }
  } else if (command === "prepare") {
    if (!option("--output")) throw new Error("prepare requires --output with a new directory");
    const onlyEvals = args.flatMap((arg, index) => arg === "--only-eval" ? [args[index + 1]] : []);
    console.log(JSON.stringify(await prepareInputs(benchmark, { directory: option("--output")!, onlyEvals: onlyEvals.length ? onlyEvals : undefined }), null, 2));
  } else if (command === "view") {
    const viewer = await serveResults({
      resultsPath: resolve(benchmark, "results"),
      port: Number(option("--port") ?? 4173),
      assetsPath: fileURLToPath(new URL("../viewer/", import.meta.url)),
    });
    console.log(viewer.url);
  } else if (command === "run" || command === "plan") {
    const result = await runBenchmark(benchmark, {
      fresh: args.includes("--new"),
      directory: option("--run"),
      models: models().length ? models() : undefined,
      onlyModels: models("--only-model").length
        ? models("--only-model")
        : undefined,
      onlyEvals: args.flatMap((arg, index) =>
        arg === "--only-eval" ? [args[index + 1]] : [],
      ).length
        ? args.flatMap((arg, index) =>
            arg === "--only-eval" ? [args[index + 1]] : [],
          )
        : undefined,
      onlyCategories: args.includes("--only-category")
        ? args.flatMap((arg, index) =>
            arg === "--only-category" ? [args[index + 1]] : [],
          )
        : undefined,
      maxCostUSD: args.includes("--max-cost")
        ? Number(option("--max-cost"))
        : undefined,
      finalOnly: args.includes("--final-only"),
      onlyRepetitions: args.includes("--only-repetition")
        ? args.flatMap((arg, index) =>
            arg === "--only-repetition" ? [Number(args[index + 1])] : [],
          )
        : undefined,
      dryRun: command === "plan",
    });
    console.log(
      JSON.stringify(
        {
          directory: result.directory,
          estimate: result.estimate,
          work: result.plan.map((item) => ({
            eval: item.slot.evalId,
            model: item.slot.model,
            repetition: item.slot.repetition,
            action: item.action,
            reason: item.reason,
          })),
          status: result.benchmark?.state,
          additionalJudges: result.additionalJudges?.length
            ? result.additionalJudges
            : undefined,
          ...("recovered" in result && result.recovered
            ? { recovered: result.recovered }
            : {}),
        },
        null,
        2,
      ),
    );
  } else if (command === "snapshot") {
    if (!args[1] || !args[2])
      throw new Error("snapshot requires a run directory and snapshot name");
    console.log(await snapshotBenchmarkRun(resolve(args[1]), args[2]));
  } else if (command === "merge-runs") {
    if (!args[1] || !args[2])
      throw new Error(
        "merge-runs requires the aggregate and source run directories",
      );
    console.log(await mergeBenchmarkRuns(resolve(args[1]), resolve(args[2])));
  } else if (command === "add-models") {
    if (!args[1])
      throw new Error("add-models requires a benchmark run directory");
    console.log((await addModels(resolve(args[1]), models())).directory);
  } else if (command === "remove-models") {
    if (!args[1])
      throw new Error("remove-models requires a benchmark run directory");
    const result = await removeModels(resolve(args[1]), models());
    console.log(JSON.stringify({
      directory: result.directory,
      removed: result.removed,
      retiredSlots: result.retiredSlots,
      status: result.benchmark.state,
    }, null, 2));
  } else if (command === "refresh-model-names") {
    if (!args[1]) throw new Error("refresh-model-names requires a benchmark run directory");
    console.log(JSON.stringify(await refreshModelNames(resolve(args[1])), null, 2));
  } else if (command === "restore") {
    const database = option("--database"), databaseHash = option("--database-hash");
    const workspaceArchive = option("--workspace-archive"), workspaceArchiveHash = option("--workspace-archive-hash");
    if (!args[1] || !args[2] || !database || !databaseHash || !workspaceArchive || !workspaceArchiveHash)
      throw new Error("restore requires the run, interrupted EvalRun, native backup, workspace tar, and both SHA-256 hashes");
    console.log(JSON.stringify(await restoreEvalRun(resolve(args[1]), args[2], {
      database: resolve(database), databaseHash, workspaceArchive: resolve(workspaceArchive), workspaceArchiveHash,
    }), null, 2));
  } else if (command === "retry") {
    const flags = args.findIndex((arg, index) => index >= 2 && arg.startsWith("--"));
    const ids = args.slice(2, flags < 0 ? args.length : flags);
    if (!args[1] || !ids.length) throw new Error("retry requires a run directory and explicit EvalRun IDs");
    const result = args.includes("--dry-run")
      ? await planEvalRunRetries(resolve(args[1]), ids)
      : await retryEvalRuns(resolve(args[1]), ids, undefined,
        { maxCostUSD: option("--max-cost") === undefined ? undefined : Number(option("--max-cost")) });
    console.log(JSON.stringify(!args.includes("--dry-run") && ids.length === 1 && Array.isArray(result)
      ? result[0] : result, null, 2));
  } else if (command === "rejudge") {
    if (!args[1] || !args[2])
      throw new Error(
        `${command} requires a benchmark run directory and eval run ID`,
      );
    const result = await judgeRun(resolve(args[1]), args[2]);
    console.log(JSON.stringify(result, null, 2));
  } else if (command === "judge-scores") {
    if (!args[1]) throw new Error("judge-scores requires a benchmark run directory");
    console.log(JSON.stringify(readJudgeScores(resolve(args[1])), null, 2));
  } else if (command === "retry-additional-judges") {
    if (!args[1]) throw new Error(`${command} requires a benchmark run directory`);
    const flags = args.findIndex((arg, index) => index >= 2 && arg.startsWith("--"));
    const ids = args.slice(2, flags < 0 ? args.length : flags);
    console.log(JSON.stringify(await retryAdditionalJudges(resolve(args[1]), {
      evalRunIds: ids.length ? ids : undefined,
      judges: models("--judge").length ? models("--judge") : undefined,
      maxCostUSD: option("--max-cost") === undefined ? undefined : Number(option("--max-cost")),
      dryRun: args.includes("--dry-run"),
    }), null, 2));
  } else
    throw new Error(
      "Commands: image, plan, run, view, add-models, remove-models, refresh-model-names, merge-runs, retry, rejudge, restore, snapshot",
    );
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
