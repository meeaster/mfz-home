import {
  query,
  type McpSdkServerConfigWithInstance,
  type Options,
  type SDKMessage,
  type SDKResultMessage,
} from "@anthropic-ai/claude-agent-sdk";
import { mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import type { Accounting, JudgeRunInput, SessionArchive } from "../../../types";
import { CandidateEvidence, type EvidenceQueryAudit } from "../../evidence";
import { errorMessage, hash, writeJson } from "../../files";
import { judgePrompt } from "../../judging/agent";
import { JudgeRequest, type SubmissionAudit } from "../../judging/submission";
import type { JudgeExecution } from "..";
import { parseJudgeModel, type JudgeModel } from "../model-ref";
import { JUDGE_SERVER, JUDGE_TOOL_NAMES, judgeToolServer } from "./tools";
import { claudeAgentSdkVersion } from "./version";
import { TRANSCRIPT } from "./transcript";

export { TRANSCRIPT } from "./transcript";

const WEB_TOOLS = ["WebSearch", "WebFetch"];

type ClaudeCodeModel = Extract<JudgeModel, { harness: "claude-code" }>;

type ResultMessage = Pick<
  SDKResultMessage,
  "type" | "subtype" | "is_error" | "num_turns" | "total_cost_usd" | "modelUsage" | "session_id"
> & { result?: string; errors?: string[] };

/** The parts of SDK messages the judge reads. */
export type ClaudeCodeMessage =
  | { type: Exclude<SDKMessage["type"], "result">; session_id?: string }
  | ResultMessage;

/** The SDK `query` entry point; tests substitute a scripted run. */
export type ClaudeCodeQuery = (params: {
  prompt: string;
  options: Options;
}) => AsyncIterable<ClaudeCodeMessage>;

/** The judge system prompt, composed as `judgeConfiguration` composes it for OpenCode. */
const judgeSystemPrompt = (
  agent: NonNullable<JudgeRunInput["agent"]>,
  rubric: string,
) => `${agent.system.trim()}\n\n# Eval rubric\n\n${rubric.trim()}`;

/** An isolated judge: no filesystem settings, CLAUDE.md, skills, hooks, plugins or configured MCP
 * servers, no built-in tools except optional web tools, and nothing outside the judge tools allowed.
 */
export function judgeOptions(
  input: Pick<JudgeRunInput, "rubric" | "websearch"> & {
    agent: NonNullable<JudgeRunInput["agent"]>;
  },
  model: ClaudeCodeModel,
  directory: string,
  server: McpSdkServerConfigWithInstance,
  abortController: AbortController,
): Options {
  const tools = input.websearch ? WEB_TOOLS : [];

  const allowedTools = [
    ...JUDGE_TOOL_NAMES.map((name) => `mcp__${JUDGE_SERVER}__${name}`),
    ...tools,
  ];

  return {
    cwd: directory,
    model: model.model,
    effort: model.effort,
    systemPrompt: judgeSystemPrompt(input.agent, input.rubric),
    settingSources: [],
    strictMcpConfig: true,
    mcpServers: { [JUDGE_SERVER]: server },
    tools,
    allowedTools,
    // Only allowedTools run; with no approval surface every other tool is denied.
    permissionMode: "dontAsk",
    permissionPrompts: "none",
    persistSession: false,
    abortController,
  };
}

/** Provider-reported totals; thinking tokens are reported inside output tokens. */
function accounting(result: ResultMessage): Accounting {
  const tokens = { input: 0, output: 0, reasoning: 0, cache: { read: 0, write: 0 } };

  for (const usage of Object.values(result.modelUsage)) {
    const reasoning = usage.thinkingTokens ?? 0;

    tokens.input += usage.inputTokens;
    tokens.output += usage.outputTokens - reasoning;
    tokens.reasoning += reasoning;
    tokens.cache.read += usage.cacheReadInputTokens;
    tokens.cache.write += usage.cacheCreationInputTokens;
  }

  return {
    costUSD: result.total_cost_usd,
    sessions: 1,
    steps: result.num_turns,
    tokens,
  };
}

const resultError = (result: ResultMessage) =>
  result.errors?.join("\n") ||
  result.result ||
  `Claude Code judge ended with ${result.subtype}`;

/** Final grading through Claude Code. No OpenCode events are emitted; the transcript is the trace. */
export async function gradeWithClaudeCode(
  input: JudgeRunInput,
  directory: string,
  run: ClaudeCodeQuery = query,
): Promise<JudgeExecution> {
  if (!input.model || !input.agent || !input.criteria.length)
    throw new Error(
      "An LLM judge requires a model, agent, and declared criteria",
    );

  const model = parseJudgeModel(input.model);

  if (model.harness !== "claude-code")
    throw new Error(`${input.model} is not a Claude Code judge model`);

  await mkdir(directory, { recursive: true });

  const evidence = await CandidateEvidence.open(
    input.evidence.directory,
    input.evidence.hash,
  );

  const queries: EvidenceQueryAudit[] = [];

  const submissions: SubmissionAudit[] = [];

  const request = new JudgeRequest(
    "final",
    evidence.view(input.evidence),
    input.criteria,
    submissions,
  );

  const messages: ClaudeCodeMessage[] = [];

  const abort = new AbortController();

  const timer = setTimeout(() => abort.abort(), input.timeoutMs);

  let outcome: JudgeExecution["result"], judgment: JudgeExecution["judgment"];

  let result: ResultMessage | undefined;

  try {
    const options = judgeOptions(
      { ...input, agent: input.agent },
      model,
      directory,
      judgeToolServer(request, queries),
      abort,
    );

    for await (const message of run({ prompt: judgePrompt("final"), options })) {
      messages.push(message);

      if (message.type === "result") result = message;
    }

    if (abort.signal.aborted) throw abort.signal.reason;

    if (!result) throw new Error("Claude Code judge ended without a result");

    if (result.subtype !== "success" || result.is_error)
      throw new Error(resultError(result));

    const decision = request.result();

    if (decision.kind !== "decided")
      throw new Error("Final grading requires a judgment submission");

    judgment = decision.judgment;

    outcome = { state: "completed" };
  } catch (error) {
    outcome = abort.signal.aborted
      ? { state: "timed_out", error: "Judge exceeded its time limit" }
      : { state: "failed", error: errorMessage(error) };
  } finally {
    clearTimeout(timer);

    request.close();

    await writeJson(resolve(directory, "evidence-queries.json"), queries);

    await writeJson(resolve(directory, "judgment-submissions.json"), submissions);
  }

  const transcript = messages.map((message) => `${JSON.stringify(message)}\n`).join("");

  await Bun.write(resolve(directory, TRANSCRIPT), transcript);

  const sessionId = messages.find((message) => message.session_id)?.session_id;

  if (!sessionId) throw new Error(outcome.error ?? "Claude Code judge did not start");

  const session: SessionArchive = {
    sessionId,
    database: TRANSCRIPT,
    databaseHash: hash(transcript),
    harness: "claude-code",
    harnessVersion: await claudeAgentSdkVersion(),
    accounting: result && accounting(result),
  };

  return { result: outcome, session, judgment };
}
