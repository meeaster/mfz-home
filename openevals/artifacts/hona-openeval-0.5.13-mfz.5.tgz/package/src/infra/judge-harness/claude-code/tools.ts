import { createSdkMcpServer, type SdkMcpToolDefinition } from "@anthropic-ai/claude-agent-sdk";
import { Schema } from "effect";
import * as z from "zod";
import type { EvidenceQueryAudit } from "../../evidence";
import { errorMessage } from "../../files";
import { criteriaSchema, STRICT_OBJECT } from "../../judging/contract";
import { evidenceTool, toolResult } from "../../judging/evidence-tool";
import type { JudgeRequest } from "../../judging/submission";

/** The in-process MCP server name; Claude Code exposes its tools as `mcp__<server>__<tool>`. */
export const JUDGE_SERVER = "openeval-judge";

export const JUDGE_TOOL_NAMES = [
  "candidate_evidence",
  "judge_context",
  "submit_judgment",
  "continue_judging",
] as const;

type ToolContent = ReturnType<typeof toolResult>["content"];

/** Arguments as the SDK server delivers them, before the Effect schema decodes them. */
type ToolArguments = Parameters<SdkMcpToolDefinition["handler"]>[0];

/** MCP tool inputs are objects. Effect describes an empty struct as any object or array. */
const EMPTY_INPUT = {
  type: "object",
  properties: {},
  additionalProperties: false,
} as const;

/** The SDK advertises Zod schemas, so the Effect schema's JSON Schema is converted to Zod.
 * The Effect schema stays authoritative: tool arguments are decoded with it again.
 */
function zodInput(schema: Schema.Constraint) {
  const document = Schema.toJsonSchemaDocument(schema);

  const root = document.schema.type === "object" ? document.schema : EMPTY_INPUT;

  return z.fromJSONSchema(
    Object.keys(document.definitions).length
      ? { ...root, $defs: document.definitions }
      : root,
  );
}

function judgeTool<T>(
  name: (typeof JUDGE_TOOL_NAMES)[number],
  description: string,
  input: Schema.ConstraintDecoder<T>,
  execute: (value: T) => Promise<{ content: ToolContent }>,
) {
  const decode = Schema.decodeUnknownSync(input);

  return {
    name,
    description,
    inputSchema: zodInput(input),
    // Validation, evidence and submission errors return to the judge as tool errors, as on OpenCode.
    async handler(args: ToolArguments) {
      try {
        const { content } = await execute(decode(args, { errors: "all" }));

        return { content };
      } catch (error) {
        return {
          isError: true,
          content: [{ type: "text" as const, text: errorMessage(error) }],
        };
      }
    },
  };
}

/** The OpenCode judge's tools for one fixed request, served in process to Claude Code.
 * Names, descriptions, validation and audits match `installJudgeTools`.
 */
export function judgeToolServer(
  request: JudgeRequest,
  queries: EvidenceQueryAudit[],
) {
  const requestId = Schema.NonEmptyString;

  const evidence = evidenceTool(request.evidence, queries, {
    active: () => request.assertActive(),
    audit: () => ({
      checkId: request.checkId,
      checkpoint: request.evidence.checkpoint,
    }),
  });

  return createSdkMcpServer({
    name: JUDGE_SERVER,
    alwaysLoad: true,
    tools: [
      judgeTool("candidate_evidence", evidence.description, evidence.input, (value) =>
        evidence.execute(value),
      ),
      judgeTool(
        "judge_context",
        "Get this request's ID, phase, declared criteria, and current evidence index as structured data. Read this at the start of each judge turn.",
        Schema.Struct({}).annotate(STRICT_OBJECT),
        async () => toolResult(request.context()),
      ),
      judgeTool(
        "submit_judgment",
        "Submit all criterion scores for this fixed evidence view. Values, required criterion IDs, citations, and exact quotes are validated before acceptance. Errors are returned to you; correct the arguments and call again. An early submission must be irreversible for every criterion. After acceptance, finish your turn.",
        Schema.Struct({
          requestId,
          scores: criteriaSchema(request.criteria),
        }).annotate(STRICT_OBJECT),
        async (value) => toolResult(await request.submit(value)),
      ),
      judgeTool(
        "continue_judging",
        "Finish this early check when more evidence is needed. Explain what is missing. This does not stop or steer the candidate. After acceptance, finish your turn.",
        Schema.Struct({
          requestId,
          reason: Schema.NonEmptyString,
        }).annotate(STRICT_OBJECT),
        async (value) => toolResult(await request.continue(value)),
      ),
    ],
  });
}
