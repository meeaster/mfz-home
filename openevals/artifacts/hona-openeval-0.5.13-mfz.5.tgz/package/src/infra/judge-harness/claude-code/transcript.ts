import type {
  JsonValue,
  SessionMessageAssistant,
  SessionMessageAssistantTool,
  SessionMessageInfo,
  ToolContent,
} from "@opencode/client";
import * as z from "zod";
import type { RecordedSession } from "../../../view";

/** The SDK message stream, saved whole in the JudgeRun directory. */
export const TRANSCRIPT = "claude-code.jsonl";

/** The judge agent name OpenCode judge sessions record, so both harnesses read alike. */
const JUDGE_AGENT = "openeval-judge";

/** OpenCode's provider slot for models that ran through Claude Code. */
const PROVIDER = "claude-code";

const json: z.ZodType<JsonValue> = z.json();

const toolInput = z.record(z.string(), json);

const assistantBlock = z.discriminatedUnion("type", [
  z.object({ type: z.literal("text"), text: z.string() }),
  z.object({ type: z.literal("thinking"), thinking: z.string() }),
  z.object({
    type: z.literal("tool_use"),
    id: z.string(),
    name: z.string(),
    input: toolInput,
  }),
]);

/** Text parts of a tool result; other parts, such as images, are not rendered. */
const resultText = z.union([
  z.string().transform((text) => [text]),
  z
    .array(z.looseObject({ type: z.string(), text: z.string().optional() }))
    .transform((parts) =>
      parts.flatMap((part) =>
        part.type === "text" && part.text !== undefined ? [part.text] : [],
      ),
    ),
]);

const userBlock = z.discriminatedUnion("type", [
  z.object({ type: z.literal("text"), text: z.string() }),
  z.object({
    type: z.literal("tool_result"),
    tool_use_id: z.string(),
    content: resultText.default([]),
    is_error: z.boolean().optional(),
  }),
]);

/** Blocks this view does not render, such as images or redacted thinking, are left out. */
const known = <Block>(schema: z.ZodType<Block>) =>
  z.array(z.unknown()).transform((blocks) =>
    blocks.flatMap((block) => {
      const parsed = schema.safeParse(block);

      return parsed.success ? [parsed.data] : [];
    }),
  );

const STOP_REASONS = ["end_turn", "stop_sequence", "tool_use", "max_tokens", "refusal"] as const;

const FINISH = {
  end_turn: "stop",
  stop_sequence: "stop",
  tool_use: "tool-calls",
  max_tokens: "length",
  refusal: "content-filter",
} as const satisfies Record<(typeof STOP_REASONS)[number], SessionMessageAssistant["finish"]>;

const sdkMessage = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("system"),
    subtype: z.string(),
    model: z.string().optional(),
    claude_code_version: z.string().optional(),
  }),
  z.object({
    type: z.literal("assistant"),
    uuid: z.string(),
    timestamp: z.string().optional(),
    message: z.object({
      id: z.string(),
      model: z.string(),
      content: known(assistantBlock),
      // Other stop reasons, and the null of a partial stream message, record no finish.
      stop_reason: z.enum(STOP_REASONS).nullish().catch(undefined),
    }),
  }),
  z.object({
    type: z.literal("user"),
    uuid: z.string(),
    timestamp: z.string().optional(),
    message: z.object({
      content: z.union([
        z.string().transform((text) => [{ type: "text" as const, text }]),
        known(userBlock),
      ]),
    }),
  }),
  z.object({
    type: z.literal("result"),
    subtype: z.string(),
    uuid: z.string().optional(),
    is_error: z.boolean().optional(),
    num_turns: z.number().optional(),
    duration_ms: z.number().optional(),
    total_cost_usd: z.number().optional(),
    result: z.string().optional(),
    errors: z.array(z.string()).optional(),
    usage: z
      .object({
        input_tokens: z.number(),
        output_tokens: z.number(),
        cache_read_input_tokens: z.number().optional(),
        cache_creation_input_tokens: z.number().optional(),
      })
      .optional(),
  }),
]);

type SdkMessage = z.output<typeof sdkMessage>;

/** Parse each recorded line; SDK message types this view does not render are skipped. */
export function parseTranscript(text: string): SdkMessage[] {
  return text.split("\n").flatMap((line) => {
    if (!line.trim()) return [];

    const parsed = sdkMessage.safeParse(JSON.parse(line));

    return parsed.success ? [parsed.data] : [];
  });
}

const toolContent = ([first = "", ...rest]: readonly string[]): [ToolContent, ...ToolContent[]] => [
  { type: "text", text: first },
  ...rest.map((text): ToolContent => ({ type: "text", text })),
];

const formatUSD = (value: number) =>
  `$${value.toFixed(value >= 1 ? 2 : 4)}`;

/** The SDK result, as recorded: outcome, turns, duration, cost, and token totals. */
function resultSummary(message: Extract<SdkMessage, { type: "result" }>) {
  const parts = [`Claude Code result: ${message.subtype}`];

  if (message.num_turns !== undefined) parts.push(`${message.num_turns} turns`);

  if (message.duration_ms !== undefined)
    parts.push(`${(message.duration_ms / 1000).toFixed(1)}s`);

  if (message.total_cost_usd !== undefined)
    parts.push(formatUSD(message.total_cost_usd));

  if (message.usage) {
    const usage = message.usage;

    parts.push(
      `${usage.input_tokens} input, ${usage.output_tokens} output, ${usage.cache_read_input_tokens ?? 0} cache read, ${usage.cache_creation_input_tokens ?? 0} cache write tokens`,
    );
  }

  return parts.join(" · ");
}

/** Convert a Claude Code SDK message stream into the session messages the recorded
 * timeline renders. Only recorded content is used: the SDK does not record the
 * prompt it was sent, and empty or redacted thinking blocks carry no text. */
export function transcriptSession(
  messages: readonly SdkMessage[],
  sessionID: string,
): RecordedSession | undefined {
  const times = messages.flatMap((message) =>
    "timestamp" in message && message.timestamp
      ? [Date.parse(message.timestamp)]
      : [],
  );

  // Init and result messages carry no timestamp; they take the nearest recorded one.
  const first = times[0] ?? 0;

  let last = first;

  const out: SessionMessageInfo[] = [];

  const tools = new Map<string, SessionMessageAssistantTool>();

  let model: string | undefined;

  for (const [index, message] of messages.entries()) {
    if (message.type === "system") {
      if (message.subtype !== "init") continue;

      model = message.model ?? model;

      out.push({
        type: "system",
        id: `init-${index}`,
        time: { created: first },
        text: "",
        description: [
          `Claude Code ${message.claude_code_version ?? ""}`.trim(),
          message.model,
        ]
          .filter(Boolean)
          .join(" · "),
      });

      continue;
    }

    if (message.type === "result") {
      out.push({
        type: "system",
        id: message.uuid ?? `result-${index}`,
        time: { created: last },
        text: message.result ?? message.errors?.join("\n") ?? "",
        description: resultSummary(message),
      });

      continue;
    }

    const created = message.timestamp ? Date.parse(message.timestamp) : last;

    last = created;

    if (message.type === "assistant") {
      model = message.message.model;

      const previous = out.at(-1);

      // The SDK streams one API message as several messages that share its ID.
      const current =
        previous?.type === "assistant" && previous.id === message.message.id
          ? previous
          : undefined;

      const target: SessionMessageAssistant = current ?? {
        type: "assistant",
        id: message.message.id,
        time: { created },
        agent: JUDGE_AGENT,
        model: { providerID: PROVIDER, id: message.message.model },
        content: [],
      };

      if (!current) out.push(target);

      if (message.message.stop_reason)
        target.finish = FINISH[message.message.stop_reason];

      target.time.completed = created;

      for (const block of message.message.content) {
        if (block.type === "text") target.content.push({ type: "text", text: block.text });

        if (block.type === "thinking" && block.thinking.trim())
          target.content.push({ type: "reasoning", text: block.thinking });

        if (block.type === "tool_use") {
          const tool: SessionMessageAssistantTool = {
            type: "tool",
            id: block.id,
            name: block.name,
            state: { status: "running", input: block.input, metadata: {} },
            time: { created },
          };

          tools.set(block.id, tool);

          target.content.push(tool);
        }
      }

      continue;
    }

    for (const block of message.message.content) {
      if (block.type === "text") {
        out.push({ type: "user", id: message.uuid, time: { created }, text: block.text });

        continue;
      }

      const tool = tools.get(block.tool_use_id);

      if (!tool || tool.state.status !== "running") continue;

      const texts = block.content;

      tool.time.completed = created;

      tool.state = block.is_error
        ? {
            status: "error",
            input: tool.state.input,
            error: { type: "tool_error", message: texts.join("\n") },
            content: toolContent(texts),
          }
        : { status: "completed", input: tool.state.input, content: toolContent(texts) };
    }
  }

  if (!model) return undefined;

  return {
    sessionID,
    title: "Final grading through Claude Code",
    created: first,
    model: { providerID: PROVIDER, id: model },
    agent: JUDGE_AGENT,
    messages: out,
    status: { type: "idle" },
    diffs: [],
    parts: {},
  };
}

/** The recorded Claude Code session; none until the judge finishes and saves its transcript. */
export async function readTranscript(
  path: string,
  sessionID: string,
): Promise<RecordedSession[]> {
  const transcript = Bun.file(path);

  if (!(await transcript.exists())) return [];

  const session = transcriptSession(parseTranscript(await transcript.text()), sessionID);

  return session ? [session] : [];
}
