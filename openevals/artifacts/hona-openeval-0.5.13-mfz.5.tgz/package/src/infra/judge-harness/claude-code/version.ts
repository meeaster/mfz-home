let sdkVersion: Promise<string> | undefined;

/** The installed Claude Agent SDK version, which also pins its bundled Claude Code executable.
 * Read from the package so that judge fingerprints follow dependency updates.
 */
export const claudeAgentSdkVersion = () =>
  (sdkVersion ??= Bun.file(
    new URL("package.json", import.meta.resolve("@anthropic-ai/claude-agent-sdk")),
  )
    .json()
    .then((manifest: { version: string }) => manifest.version));
