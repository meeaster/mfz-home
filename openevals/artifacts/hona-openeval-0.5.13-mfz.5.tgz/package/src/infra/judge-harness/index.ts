import type { JudgeSession } from "../../evidence";
import type {
  JudgeRunInput,
  Judgment,
  OpenCodeStreamEvent,
  SessionArchive,
  SessionState,
} from "../../types";
import { executeJudge } from "../judging";
import { createJudgeSession } from "../judging/observer";
import { gradeWithClaudeCode } from "./claude-code";
import { openCodeJudgeModel, parseJudgeModel, type JudgeModelRef } from "./model-ref";

/** One final grading of finalized evidence. A missing judgment means the judge did not submit. */
export type JudgeExecution = {
  result: { state: Exclude<SessionState, "running">; error?: string };
  session: SessionArchive;
  judgment?: Judgment;
};

export type MonitoringJudgeInput = Pick<
  JudgeRunInput,
  "model" | "rubric" | "timeoutMs" | "websearch" | "criteria" | "agent"
>;

/** A persistent judge that checks evidence views while the candidate runs. */
export type MonitoringJudge = JudgeSession & {
  setCheck(id: string): void;
  close(): Promise<SessionArchive | undefined>;
};

/** LLM judge mechanics for the harness named by the judge model reference. */
export type JudgeHarness = {
  grade(
    input: JudgeRunInput,
    directory: string,
    onEvent: (event: OpenCodeStreamEvent) => void,
  ): Promise<JudgeExecution>;
  monitor(
    input: MonitoringJudgeInput,
    directory: string,
    onEvent: (event: OpenCodeStreamEvent) => void,
  ): Promise<MonitoringJudge>;
};

/** Unprefixed references keep the existing in-process OpenCode judge unchanged. */
const openCodeHarness: JudgeHarness = {
  grade: (input, directory, onEvent) =>
    executeJudge(
      { ...input, model: input.model && openCodeJudgeModel(input.model) },
      directory,
      onEvent,
    ),
  monitor: (input, directory, onEvent) =>
    createJudgeSession(
      { ...input, model: input.model && openCodeJudgeModel(input.model) },
      directory,
      onEvent,
    ),
};

/** Claude Code judges grade finalized evidence; they record no OpenCode events. */
const claudeCodeHarness = (ref: string): JudgeHarness => ({
  grade: (input, directory) => gradeWithClaudeCode(input, directory),
  monitor: async () => {
    throw new Error(
      `${ref} grades finalized evidence only; earlyStop requires an OpenCode judge.model`,
    );
  },
});

export function judgeHarness(model: JudgeModelRef | undefined): JudgeHarness {
  // Without a model, the OpenCode judge reports its existing configuration error.
  if (!model) return openCodeHarness;

  const selected = parseJudgeModel(model);

  switch (selected.harness) {
    case "opencode":
      return openCodeHarness;
    case "claude-code":
      return claudeCodeHarness(selected.ref);
  }
}

export const gradeWithJudgeHarness: JudgeHarness["grade"] = (
  input,
  directory,
  onEvent,
) => judgeHarness(input.model).grade(input, directory, onEvent);

export const monitorWithJudgeHarness: JudgeHarness["monitor"] = (
  input,
  directory,
  onEvent,
) => judgeHarness(input.model).monitor(input, directory, onEvent);
