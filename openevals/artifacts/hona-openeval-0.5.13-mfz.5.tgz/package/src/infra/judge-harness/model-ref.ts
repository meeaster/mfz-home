import type { EffortLevel } from "@anthropic-ai/claude-agent-sdk";
import type { EvalDefinition, Judge, ModelRef } from "../../types";

/** A judge model: unprefixed `provider/model[#variant]` runs through OpenCode;
 * `claude-code:model[#effort]` names a Claude Code judge.
 */
export type JudgeModelRef = NonNullable<Judge["model"]>;

/** The harness that runs a judge model and its harness-native model selection. */
export type JudgeModel =
  | { harness: "opencode"; ref: ModelRef }
  | {
      harness: "claude-code";
      ref: `claude-code:${string}`;
      model: string;
      effort?: EffortLevel;
    };

/** The effort levels the Claude Agent SDK accepts for `options.effort`. */
const CLAUDE_CODE_EFFORTS = ["low", "medium", "high", "xhigh", "max"] as const satisfies readonly EffortLevel[];

const isEffort = (value: string): value is EffortLevel =>
  CLAUDE_CODE_EFFORTS.some((effort) => effort === value);

const OPENCODE_MODEL = /^[\w.-]+\/[^\s/#]+(?:\/[^\s/#]+)*(?:#[\w.-]+)?$/;

const CLAUDE_CODE_PREFIX = /^claude-code:/;

const CLAUDE_CODE_MODEL = /^claude-code:([\w.-]+)(?:#([\w.-]+))?$/;

const isModelRef = (value: string): value is ModelRef =>
  OPENCODE_MODEL.test(value);

const isClaudeCodeRef = (value: string): value is `claude-code:${string}` =>
  CLAUDE_CODE_PREFIX.test(value);

export function parseJudgeModel(value: string): JudgeModel {
  if (isModelRef(value)) return { harness: "opencode", ref: value };

  const claudeCode = CLAUDE_CODE_MODEL.exec(value);

  if (claudeCode && isClaudeCodeRef(value)) {
    const [, model, effort] = claudeCode;

    if (effort === undefined) return { harness: "claude-code", ref: value, model };

    if (isEffort(effort)) return { harness: "claude-code", ref: value, model, effort };

    throw new Error(
      `Invalid Claude Code effort in ${value}; use one of ${CLAUDE_CODE_EFFORTS.join(", ")}`,
    );
  }

  throw new Error(
    `Invalid judge model reference: ${value}; use provider/model[#variant] for OpenCode or claude-code:model[#effort] for Claude Code`,
  );
}

/** Validate a judge model reference for loading. */
export const loadableJudgeModel = (value: string): JudgeModelRef =>
  parseJudgeModel(value).ref;

/** Narrow a judge reference for the OpenCode judge. */
export function openCodeJudgeModel(value: string): ModelRef {
  const model = parseJudgeModel(value);

  if (model.harness !== "opencode")
    throw new Error(`${model.ref} is not an OpenCode judge model`);

  return model.ref;
}

/** Claude Code judges grade finalized evidence only; early checks need a monitoring judge. */
export function rejectClaudeCodeMonitor(
  judge: string | undefined,
  evals: readonly Pick<EvalDefinition, "settings">[],
) {
  if (!judge || parseJudgeModel(judge).harness !== "claude-code") return;

  if (evals.some((item) => item.settings.earlyStop))
    throw new Error(
      `${judge} grades finalized evidence only; earlyStop requires an OpenCode judge.model`,
    );
}

/** Candidate models always run through OpenCode. */
export function rejectClaudeCodeCandidate(value: string) {
  if (isClaudeCodeRef(value))
    throw new Error(
      `Candidate models run through OpenCode; ${value} is only valid as judge.model`,
    );
}
