import { Database } from "@opencode/core/database/database";
import { Global } from "@opencode/util/global";
import { makeGlobalNode } from "@opencode/util/effect/app-node";
import { Context, Effect, Layer } from "effect";
import { Database as SQLite } from "bun:sqlite";
import { isAbsolute, join } from "node:path";
import { z } from "zod";
import type { ModelRef } from "../../types";
import { OPENCODE_VERSION } from "./version";

export type Credential = {
  id: string;
  integration_id: string | null;
  label: string;
  value: string;
  connector_id: string | null;
  method_id: string | null;
  active: number | null;
  time_created: number;
  time_updated: number;
};

export const localCredentialPath = () => {
  const path = process.env.OPENCODE_DB ?? "opencode.db";

  return isAbsolute(path) ? path : join(Global.Path.data, path);
};

export function createCredentialSnapshot(
  source = localCredentialPath(),
  integrations?: readonly string[],
): Credential[] {
  const db = new SQLite(source, { readonly: true });

  try {
    const rows = db
      .query(
        "SELECT id,integration_id,label,value,connector_id,method_id,active,time_created,time_updated FROM credential",
      )
      .all() as Credential[];

    return rows
      .filter(
        (row) =>
          row.active !== 0 &&
          (!integrations || integrations.includes(row.integration_id ?? "")),
      )
      .map((row) => {
        const parsed = JSON.parse(row.value) as {
          type: string;
          refresh?: string;
        };

        return {
          ...row,
          value:
            parsed.type === "oauth"
              ? JSON.stringify({ ...parsed, refresh: "" })
              : row.value,
        };
      });
  } finally {
    db.close(true);
  }
}

/**
 * ChatGPT token sharing, as `@opencode/core` 2.0.27's ChatGPT plugin implements it. Snapshots drop the refresh
 * token, so a container cannot renew an access token that expires mid-run; its renewal request fails with 400.
 * The host renews instead, before the snapshot, exactly as the plugin would, and writes the result back.
 */
const tokenSharingMethod = "chatgpt-token-sharing";

const tokenSharingURL = "https://auth.openai.com/api/accounts/oauth/token";

const tokenSharingResource = "https://api.openai.com/v1";

/** A candidate or judge server stops after 45 minutes, so a snapshot's access token must outlive that. */
export const minimumCredentialLifetimeMs = 50 * 60_000;

const tokenSharingCredential = z.looseObject({
  type: z.literal("oauth"),
  methodID: z.literal(tokenSharingMethod),
  refresh: z.string().min(1),
  expires: z.number(),
  metadata: z.looseObject({
    clientID: z.string(),
    scopes: z.array(z.string()).optional(),
  }),
});

export type TokenSharingCredential = z.infer<typeof tokenSharingCredential>;

const tokenResponse = z.object({
  access_token: z.string(),
  refresh_token: z.string(),
  expires_in: z.number().optional(),
  scope: z.string().optional(),
});

export type TokenResponse = z.infer<typeof tokenResponse>;

export type TokenRefresh = (
  credential: TokenSharingCredential,
) => Promise<TokenResponse>;

export const requestTokenRefresh: TokenRefresh = async (credential) => {
  const response = await fetch(tokenSharingURL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "User-Agent": `opencode/openeval/${OPENCODE_VERSION}/openeval`,
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      client_id: credential.metadata.clientID,
      refresh_token: credential.refresh,
      resource: tokenSharingResource,
    }).toString(),
  });

  if (!response.ok)
    throw new Error(
      `Renewing the ChatGPT connection failed with ${response.status}; sign in to OpenCode again`,
    );

  return tokenResponse.parse(await response.json());
};

const renewalRow = z.object({
  id: z.string(),
  value: z.string(),
  time_updated: z.number(),
});

/** The credential the plugin's own renewal stores: new tokens, the same client, and the granted scopes. */
function renewedCredential(
  credential: TokenSharingCredential,
  tokens: TokenResponse,
  now: number,
) {
  return {
    type: "oauth",
    methodID: tokenSharingMethod,
    refresh: tokens.refresh_token,
    access: tokens.access_token,
    expires: now + (tokens.expires_in ?? 3600) * 1000,
    metadata: {
      clientID: credential.metadata.clientID,
      scopes:
        tokens.scope?.split(" ").filter(Boolean) ??
        credential.metadata.scopes ??
        [],
    },
  };
}

/**
 * Renews token-sharing credentials that would expire within the minimum lifetime. The write is conditional on
 * the row being unchanged since it was read, so a renewal by the host's own OpenCode in the meantime wins.
 */
export async function renewExpiringCredentials(
  source: string,
  integrations: readonly string[],
  refresh: TokenRefresh = requestTokenRefresh,
  now: () => number = Date.now,
) {
  const db = new SQLite(source);

  try {
    db.exec("PRAGMA busy_timeout=5000");

    const placeholders = integrations.map(() => "?").join(",");

    const rows = z
      .array(renewalRow)
      .parse(
        db
          .query(
            `SELECT id,value,time_updated FROM credential WHERE active != 0 AND integration_id IN (${placeholders})`,
          )
          .all(...integrations),
      );

    for (const row of rows) {
      const parsed = tokenSharingCredential.safeParse(JSON.parse(row.value));

      if (!parsed.success) continue;

      if (parsed.data.expires > now() + minimumCredentialLifetimeMs) continue;

      const tokens = await refresh(parsed.data);

      const renewedAt = now();

      db.query(
        "UPDATE credential SET value = ?, time_updated = ? WHERE id = ? AND time_updated = ?",
      ).run(
        JSON.stringify(renewedCredential(parsed.data, tokens, renewedAt)),
        renewedAt,
        row.id,
        row.time_updated,
      );
    }
  } finally {
    db.close(true);
  }
}

/** Concurrent candidates and judges renew one at a time, so the second sees the first's fresh token. */
let renewal: Promise<void> = Promise.resolve();

function renewSerially(integrations: readonly string[]) {
  const next = renewal.then(() =>
    renewExpiringCredentials(localCredentialPath(), integrations),
  );

  renewal = next.catch(() => undefined);

  return next;
}

/** Console-routed providers authenticate through the OpenCode connection. */
export const integrationFor = (model: ModelRef) => {
  const provider = model.split("/")[0];

  return provider.startsWith("console-") ? "opencode" : provider;
};

export const credentialsFor = async (
  model: ModelRef,
  websearch: "exa" | false,
) => {
  const integration = integrationFor(model);

  const required = [
    ...new Set([integration, ...(websearch ? ["opencode", "exa"] : [])]),
  ];

  await renewSerially(required);
  const credentials = createCredentialSnapshot(undefined, required);

  if (!credentials.some((row) => row.integration_id === integration))
    throw new Error(`No active OpenCode connection for ${integration}`);

  return credentials;
};

/** A catalog container's snapshot, renewed first like a candidate's. */
export const catalogCredentialsFor = async (integration: string) => {
  await renewSerially([integration]);

  return createCredentialSnapshot(undefined, [integration]);
};

export const databaseWithCredentials = (
  path: string,
  credentials: Credential[],
) =>
  makeGlobalNode({
    service: Database.Service,
    layer: Database.layer({ path }).pipe(
      Layer.tap((context) => {
        const database = Context.get(context, Database.Service);

        return Effect.gen(function* () {
          for (const row of credentials) {
            const values = [
              row.id,
              row.integration_id,
              row.label,
              row.value,
              row.connector_id,
              row.method_id,
              row.active,
              row.time_created,
              row.time_updated,
            ].map((value) =>
              value === null
                ? "NULL"
                : typeof value === "number"
                  ? String(value)
                  : `'${value.replaceAll("'", "''")}'`,
            );

            yield* database.db
              .run(
                `INSERT INTO credential (id,integration_id,label,value,connector_id,method_id,active,time_created,time_updated) VALUES (${values.join(",")})`,
              )
              .pipe(Effect.orDie);
          }
        });
      }),
    ),
    deps: [Global.node],
  });

/** Purge secrets before the database becomes a finalized evidence artifact. */
export function removeCredentials(path: string) {
  const db = new SQLite(path);

  try {
    db.exec(
      "PRAGMA busy_timeout=5000; PRAGMA wal_checkpoint(TRUNCATE); PRAGMA secure_delete=ON; DELETE FROM credential; VACUUM; PRAGMA wal_checkpoint(TRUNCATE);",
    );
  } finally {
    db.close(true);
  }
}
