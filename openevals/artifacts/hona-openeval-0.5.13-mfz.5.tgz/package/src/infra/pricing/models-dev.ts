import { Schema } from "effect";
import type { Accounting, OpenCodeStreamEvent } from "../../types";

const MODELS_DEV_URL = "https://models.dev/api.json";

/** USD per million tokens. */
const Rate = Schema.Struct({
  input: Schema.Finite,
  output: Schema.Finite,
  reasoning: Schema.optional(Schema.Finite),
  cache_read: Schema.optional(Schema.Finite),
  cache_write: Schema.optional(Schema.Finite),
});

/** A context tier replaces the base rate once a request's prompt exceeds its size. */
const Cost = Schema.Struct({
  ...Rate.fields,
  tiers: Schema.optional(
    Schema.Array(
      Schema.Struct({
        ...Rate.fields,
        tier: Schema.Struct({ type: Schema.String, size: Schema.Finite }),
      }),
    ),
  ),
});

type Rate = typeof Rate.Type;

const ModelEntry = Schema.Struct({ cost: Cost });

const Catalog = Schema.Record(
  Schema.String,
  Schema.Struct({ models: Schema.Record(Schema.String, Schema.Unknown) }),
);

type Tokens = Accounting["tokens"];

export type ModelPrice = (providerID: string, modelID: string, prompt: number) => Rate | undefined;

/** List prices from the models.dev catalog. Each model is decoded on lookup, so one malformed entry prices nothing else wrong. */
export function modelsDevPrices(catalog: typeof Catalog.Type): ModelPrice {
  return (providerID, modelID, prompt) => {
    const entry = Schema.decodeUnknownOption(ModelEntry)(catalog[providerID]?.models[modelID]);

    if (entry._tag === "None") return undefined;

    const { tiers, ...base } = entry.value.cost;

    return tiers?.filter((tier) => tier.tier.type === "context" && prompt > tier.tier.size).at(-1) ?? base;
  };
}

let fetched: Promise<ModelPrice | undefined> | undefined;

/** The current models.dev list prices, fetched once per process; undefined when the catalog is unreachable. */
export function fetchModelsDevPrices(): Promise<ModelPrice | undefined> {
  fetched ??= fetch(MODELS_DEV_URL, { signal: AbortSignal.timeout(15_000) })
    .then(async (response) => (response.ok ? modelsDevPrices(Schema.decodeUnknownSync(Catalog)(await response.json())) : undefined))
    .catch(() => undefined);

  return fetched;
}

const requestUSD = (rate: Rate, tokens: Tokens) =>
  (tokens.input * rate.input +
    tokens.output * rate.output +
    tokens.reasoning * (rate.reasoning ?? rate.output) +
    tokens.cache.read * (rate.cache_read ?? rate.input) +
    tokens.cache.write * (rate.cache_write ?? rate.input)) /
  1_000_000;

/**
 * Prices each model request at list price, for subscriptions that report no cost. A step's model comes from
 * `session.step.started` and its tokens from the matching end or failure; requests without a known model or price,
 * such as title generation, are counted as unpriced.
 */
export class RequestPricing {
  private models = new Map<string, { providerID: string; id: string }>();

  private requests: { model?: { providerID: string; id: string }; tokens: Tokens }[] = [];

  /** Failed steps that ended without recorded tokens. */
  private untracked = 0;

  observe(event: OpenCodeStreamEvent) {
    if (event.type === "session.step.started")
      this.models.set(`${event.data.sessionID}:${event.data.assistantMessageID}`, event.data.model);

    if (event.type === "session.step.ended" || event.type === "session.step.failed") {
      const model = this.models.get(`${event.data.sessionID}:${event.data.assistantMessageID}`);

      if (event.data.tokens === undefined) this.untracked++;
      else this.requests.push({ model, tokens: event.data.tokens });
    }

    if (event.type === "session.usage.recorded") this.requests.push({ tokens: event.data.tokens });
  }

  estimate(price: ModelPrice): NonNullable<Accounting["estimate"]> {
    let usd = 0;

    let unpriced = this.untracked;

    for (const { model, tokens } of this.requests) {
      const rate = model && price(model.providerID, model.id, tokens.input + tokens.cache.read + tokens.cache.write);

      if (rate) usd += requestUSD(rate, tokens);
      else unpriced++;
    }

    return { source: "models.dev", usd, unpriced };
  }
}

/** Adds the list-price estimate to accounting that reports no cost, when the models.dev catalog is reachable. */
export async function withListPrice(accounting: Accounting, pricing: RequestPricing): Promise<Accounting> {
  if (accounting.costUSD !== 0 || accounting.steps === 0) return accounting;

  const price = await fetchModelsDevPrices();

  return price ? { ...accounting, estimate: pricing.estimate(price) } : accounting;
}
