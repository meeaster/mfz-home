import type { SessionState } from "./types";
import type { ModelScore } from "./view";

/** The harness that ran a judge model: `claude-code:` references run through Claude Code. */
export type JudgeHarnessName = "opencode" | "claude-code";

export const judgeHarnessOf = (ref: string): JudgeHarnessName =>
  ref.startsWith("claude-code:") ? "claude-code" : "opencode";

/** One judge of a BenchmarkRun with the scores its own judgments produce. */
export type JudgeScoresView = {
  /** Absent for a benchmark whose evals are judged only by judge.ts. */
  ref?: string;
  harness: JudgeHarnessName;
  primary: boolean;
  scores: ModelScore[];
};

/** One judge's JudgeRun of an EvalRun: the completed one, else the latest attempt. */
export type JudgeVerdict = {
  judgeRunId: string;
  state: SessionState;
  value: number | null;
  scores: Record<string, { value: number | null; reason: string }>;
};

export type JudgedEvalRun = {
  slotId: string;
  evalId: string;
  model: string;
  repetition: number;
  evalRunId?: string;
  /** Aligned with `JudgeComparison.judges`; null when that judge has no JudgeRun here. */
  verdicts: Array<JudgeVerdict | null>;
};

/** Each judge's scores and judgments, side by side and never averaged together. */
export type JudgeComparison = {
  judges: JudgeScoresView[];
  evalRuns: JudgedEvalRun[];
};
