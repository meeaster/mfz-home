import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Dx0XIc-K.js";import"./chunk-DU6HZSFF-fcvrCc4R.js";import"./chunk-75Z2AOVW-DgkLMMl-.js";import"./chunk-PWAF6VOD-CjemUlMv.js";import"./chunk-GMAD6QVW-TQTARxq-.js";import"./chunk-P2QGCYS3-C-yCxAng.js";import"./chunk-4HAMMTFA-njlSWHDb.js";import"./chunk-GVQU2GXP-CuS9l5uy.js";import"./chunk-OSK3NFVY-DUrDCpSH.js";import"./chunk-F27PBJKO-kXWJof45.js";import"./chunk-XXDRQBXY-DnT6QUjt.js";import"./chunk-POPQ4Y6H-BhwjJBLN.js";import"./chunk-L3NEJ4N5-D742y7Xu.js";import{r as t,t as n}from"./chunk-SHT3W25Y-zwVyq3TQ.js";import"./mermaid.core-SVjVpY-F.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};